Placeholder for the Settings screen (theme/accent color picker, list
layout toggle, premium unlock via lib/ads_iap). Not yet implemented.
