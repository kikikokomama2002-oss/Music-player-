/// A single timestamped lyric line.
class LyricLine {
  const LyricLine(this.timestamp, this.text);
  final Duration timestamp;
  final String text;
}

/// Parses standard `.lrc` synced lyric files, e.g.:
///   [00:12.34]First line of lyrics
///   [00:15.67]Second line
///
/// Lines without a valid `[mm:ss.xx]` tag are ignored (treated as
/// metadata like [ar:], [ti:], [al:]). Falls back gracefully — if no
/// lines parse, callers should fall back to embedded ID3 lyrics or
/// plain-text display.
class LrcParser {
  static final _tagExp = RegExp(r'^\[(\d{1,3}):(\d{2})(?:\.(\d{1,3}))?\]');
  static final _offsetExp = RegExp(r'^\[offset:([+-]?\d+)\]$', caseSensitive: false);

  static List<LyricLine> parse(String raw) {
    final lines = <LyricLine>[];
    var offsetMs = 0;

    for (final rawLine in raw.removePrefix('\uFEFF').split(RegExp(r'\r?\n'))) {
      var remaining = rawLine.trim();
      final offsetMatch = _offsetExp.firstMatch(remaining);
      if (offsetMatch != null) {
        offsetMs = int.tryParse(offsetMatch.group(1)!) ?? offsetMs;
        continue;
      }
      final timestamps = <Duration>[];

      // LRC permits several timestamps on one physical line:
      // [00:12.34][00:25.10]same lyric text
      while (true) {
        final match = _tagExp.firstMatch(remaining);
        if (match == null) break;
        final minutes = int.parse(match.group(1)!);
        final seconds = int.parse(match.group(2)!);
        if (seconds >= 60) break;
        final fraction = match.group(3);
        final millis = fraction == null
            ? 0
            : int.parse(fraction.padRight(3, '0').substring(0, 3));
        timestamps.add(Duration(
          minutes: minutes,
          seconds: seconds,
          milliseconds: millis,
        ));
        remaining = remaining.substring(match.end).trimLeft();
      }

      if (timestamps.isEmpty) continue;
      final text = remaining.trim();
      if (text.isEmpty) continue;
      for (final timestamp in timestamps) {
        final adjustedMs = timestamp.inMilliseconds + offsetMs;
        lines.add(
          LyricLine(
            Duration(milliseconds: adjustedMs < 0 ? 0 : adjustedMs),
            text,
          ),
        );
      }
    }

    lines.sort((a, b) => a.timestamp.compareTo(b.timestamp));
    return lines;
  }

  /// Returns the index of the currently active line for a given playback
  /// position, or -1 if before the first line. Used to drive a synced
  /// auto-scrolling lyrics view.
  static int activeLineIndex(List<LyricLine> lines, Duration position) {
    int active = -1;
    for (var i = 0; i < lines.length; i++) {
      if (lines[i].timestamp <= position) {
        active = i;
      } else {
        break;
      }
    }
    return active;
  }
}
