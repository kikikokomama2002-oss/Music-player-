import 'dart:io';
import 'package:permission_handler/permission_handler.dart';

/// Requests the correct storage/media permission depending on Android
/// version: READ_MEDIA_AUDIO on API 33+, READ_EXTERNAL_STORAGE below it.
class PermissionsHelper {
  static Future<bool> requestAudioPermission() async {
    if (!Platform.isAndroid) return true;

    final audioStatus = await Permission.audio.status;
    if (audioStatus.isGranted) return true;

    final result = await Permission.audio.request();
    if (result.isGranted) return true;

    // Pre-Android 13 fallback.
    final storageResult = await Permission.storage.request();
    return storageResult.isGranted;
  }

  static Future<bool> requestNotificationPermission() async {
    if (!Platform.isAndroid) return true;
    final status = await Permission.notification.status;
    if (status.isGranted) return true;
    final result = await Permission.notification.request();
    return result.isGranted;
  }
}
