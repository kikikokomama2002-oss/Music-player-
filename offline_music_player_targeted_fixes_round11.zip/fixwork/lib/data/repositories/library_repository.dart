import 'dart:async';
import 'dart:convert';
import 'package:isar_community/isar_community.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../playback/player_channel.dart';
import '../db/track.dart';

const _lastScanKey = 'last_scan_timestamp_ms';
const _volumeIdentityMigrationKey = 'volume_identity_migration_v1';
const _knownMediaStoreVolumesKey = 'known_media_store_volumes_v1';
const _mediaStoreVolumeStatesKey = 'media_store_volume_states_v1';

/// Safety overlap applied to the incremental scan cursor so a track
/// modified in the same second as the last scan (MediaStore's
/// DATE_MODIFIED has 1-second resolution) is never skipped.
const _scanOverlapMs = 2000;

/// Maximum number of local MediaStore IDs compared with Android in one
/// deletion-sync batch. The native query uses the same bounded batch, so
/// neither side scales in memory with the full library size.
const _deletionSyncChunkSize = 500;

/// Which grouping tab a query is for. Each case maps to a real indexed
/// column on [Track] (`album`, `artist`, `folder`), so grouping never
/// falls back to scanning/deserializing every row.
enum GroupField { album, artist, folder }

/// A group's display name and track count, resolved entirely at the DB
/// layer (distinct index scan + indexed `count()`) — never by loading
/// every [Track] in the group into memory just to read `.length`.
class GroupSummary {
  const GroupSummary(this.name, this.trackCount, {String? displayName})
      : displayName = displayName ?? name;
  /// Stable DB/query key. For folders this remains volume-qualified.
  final String name;
  /// Human-facing label; keeps the storage-volume prefix out of the UI.
  final String displayName;
  final int trackCount;
}

/// Orchestrates scan -> bulk DB write -> deletion sync. The native scan
/// already runs off the platform's main thread; the Dart side keeps
/// writes batched in a single Isar transaction so refreshing a large
/// library never causes jank in the widget tree.
class LibraryRepository {
  LibraryRepository(this._isar);
  final Isar _isar;

  // Only one library scan may mutate/reconcile Isar at a time. Repeated
  // requests while a scan is active coalesce onto the same Future rather
  // than starting a second snapshot/deletion reconciliation concurrently.
  Future<void>? _scanInFlight;
  int _scanRequestGeneration = 0;
  int _libraryGeneration = 0;

  /// Monotonically changes whenever a scan/reconciliation transaction may
  /// mutate the queryable library. Queue readers use this as a lightweight
  /// snapshot invalidation token. It is intentionally bumped before the
  /// asynchronous scan begins, so a queue request cannot finish against a
  /// dataset whose mutation has already started.
  int get libraryGeneration => _libraryGeneration;

  /// FIX #2: fires the `mediaStoreId`s of any tracks removed by
  /// [_syncDeletions] (i.e. deleted from device storage since the last
  /// scan). `PlaybackController` forwards these straight to the native
  /// queue so a track that's playing (or queued) right now gets pruned
  /// immediately instead of the native side only finding out the next
  /// time it happens to re-fetch that page.
  final _tracksDeletedController = StreamController<List<String>>.broadcast();
  Stream<List<String>> get tracksDeleted => _tracksDeletedController.stream;

  /// Fires when existing rows are inserted or updated by a scan. The playback
  /// queue uses this only as a lightweight invalidation signal; native
  /// re-anchors on the currently playing identity and re-resolves its window.
  final _tracksChangedController = StreamController<void>.broadcast();
  Stream<void> get tracksChanged => _tracksChangedController.stream;

  /// Prevent duplicate embedded/sidecar lookups for the same track when two
  /// lyrics screens/widgets ask at nearly the same time.
  final Map<String, Future<String?>> _lyricsInFlight = {};

  void disposeStreams() {
    _tracksDeletedController.close();
    _tracksChangedController.close();
    _lyricsInFlight.clear();
  }

  /// Scans for new/changed tracks, upserts them, and removes any track
  /// whose underlying file no longer exists in MediaStore (deleted from
  /// device storage since the last scan) so stale entries don't linger
  /// in the library.
  Future<void> scanAndPersist() async {
    // Every caller waits until the scan generation that was current when it
    // requested a refresh has been fully covered. If another caller requests
    // a scan while one is running, the same Future chain performs the
    // follow-up pass before the original waiter returns; no fire-and-forget
    // scan is hidden behind an already-completed Future.
    final requestedGeneration = ++_scanRequestGeneration;
    while (true) {
      final active = _scanInFlight;
      if (active != null) {
        await active;
      } else {
        late final Future<void> scan;
        scan = _scanAndPersistInternal();
        _scanInFlight = scan;
        try {
          await scan;
        } finally {
          if (identical(_scanInFlight, scan)) {
            _scanInFlight = null;
          }
        }
      }

      if (requestedGeneration == _scanRequestGeneration) return;
      // A newer request arrived while this pass was in flight. Loop and
      // become a waiter for the latest coalesced pass.
    }
  }

  Future<void> _scanAndPersistInternal() async {
    _libraryGeneration++;
    final prefs = await SharedPreferences.getInstance();
    final lastScan = prefs.getInt(_lastScanKey) ?? 0;
    final volumeMigrationComplete =
        prefs.getBool(_volumeIdentityMigrationKey) ?? false;

    // Capture the upper cursor before any MediaStore query. DATE_MODIFIED has
    // second resolution, so persist this captured second (with the existing
    // overlap) rather than the wall-clock time after a potentially long
    // multi-volume scan. A change that happens after this point is therefore
    // guaranteed to be considered by a later scan.
    final currentSecond =
        DateTime.now().millisecondsSinceEpoch ~/ 1000;
    // MediaStore DATE_MODIFIED has second resolution. Exclude the current
    // (possibly still changing) second from this snapshot; the 2-second
    // overlap on the next pass guarantees those changes are picked up.
    final scanUntilMs = ((currentSecond - 1).clamp(0, currentSecond)).toInt() * 1000;

    // Volume lifecycle: a newly inserted/reinserted volume can contain files
    // older than the global last-scan cursor. Compare the exact current set
    // with the set from the last successful scan and perform one bounded full
    // MediaStore scan when a volume reappears. This does not wipe Isar and it
    // does not force a full scan on ordinary startups.
    final currentVolumes =
        await PlayerChannel.instance.getMediaStoreVolumes();
    final currentVolumeStates =
        await PlayerChannel.instance.getMediaStoreVolumeStates();
    final savedVolumeStates =
        prefs.getString(_mediaStoreVolumeStatesKey) ?? '{}';
    final volumeStateChanged = currentVolumeStates.entries.any((entry) {
      final old = _decodeVolumeState(savedVolumeStates, entry.key);
      return old == null || old['version'] != entry.value['version'] ||
          old['generation'] != entry.value['generation'];
    });
    final knownVolumes =
        (prefs.getStringList(_knownMediaStoreVolumesKey) ?? const <String>[])
            .toSet();
    final hasNewVolume = currentVolumes.any((v) => !knownVolumes.contains(v));

    // The first run after introducing volume-aware identity must discover
    // older audio files on secondary volumes too. A newly/reinserted volume
    // gets the same one-time full scan treatment; normal scans stay
    // incremental.
    final forceFullScan = !volumeMigrationComplete || hasNewVolume || volumeStateChanged;
    final scanSince = forceFullScan || lastScan == 0
        ? 0
        : (lastScan - _scanOverlapMs).clamp(0, lastScan).toInt();

    const scanChunkSize = 500;
    var changedAny = false;

    // Scan one volume/page at a time. The previous implementation built one
    // giant Dart list from the entire MediaStore result before touching Isar;
    // that defeated the bounded-memory design for large libraries. The
    // captured [scanUntilMs] makes every page a stable snapshot boundary.
    for (final volume in currentVolumes) {
      var cursorDateModifiedSeconds = 9223372036854775807;
      var cursorMediaStoreId = 9223372036854775807;
      while (true) {
        final rawTracks = await _readScanPageWithEmptyRetry(
          volume: volume,
          sinceTimestamp: scanSince,
          untilTimestamp: scanUntilMs,
          cursorDateModifiedSeconds: cursorDateModifiedSeconds,
          cursorMediaStoreId: cursorMediaStoreId,
          limit: scanChunkSize,
        );
        if (rawTracks.isEmpty) break;
        final tracks = rawTracks
            .map((m) {
              final rowVolume = m['volume'];
              if (rowVolume is! String || rowVolume.trim().isEmpty) {
                throw StateError('MediaStore scan row is missing a valid volume');
              }
              final normalizedVolume = rowVolume.trim();
              if (normalizedVolume != volume) {
                throw StateError(
                  'MediaStore scan row volume mismatch: expected $volume, got $normalizedVolume',
                );
              }
              final rowId = m['id'];
              if (rowId is! num || !rowId.isFinite || rowId <= 0 || rowId % 1 != 0) {
                throw StateError('MediaStore scan row has an invalid ID');
              }
              return Track()
                ..mediaStoreVolume = normalizedVolume
                ..mediaStoreId = rowId.toInt()
                ..title = (m['title'] as String?)?.trim().isNotEmpty == true
                    ? m['title'] as String
                    : 'Unknown Title'
                ..artist = (m['artist'] as String?)?.trim().isNotEmpty == true
                    ? m['artist'] as String
                    : 'Unknown Artist'
                ..album = (m['album'] as String?)?.trim().isNotEmpty == true
                    ? m['album'] as String
                    : 'Unknown Album'
                ..durationMs = (m['duration'] as num?)?.toInt() ?? 0
                ..contentUri = (m['contentUri'] as String?) ?? ''
                ..relativePath = m['relativePath'] as String?
                ..displayName = (m['displayName'] as String?) ?? ''
                ..dateModified = (m['dateModified'] as num?)?.toInt() ?? 0;
            })
            .where((t) => t.contentUri.isNotEmpty)
            .toList(growable: false);

        if (tracks.isNotEmpty) {
          for (final t in tracks) {
            t.folder = Track.computeFolder(
              relativePath: t.relativePath,
              album: t.album,
              volume: t.mediaStoreVolume,
            );
          }
          changedAny = await _persistScanBatch(tracks) || changedAny;
        }

        // A short page is not treated as terminal. Some MediaStore/OEM
        // providers legally return fewer rows than QUERY_ARG_LIMIT while
        // more rows remain. Continue from the last returned key until the
        // provider explicitly returns an empty page.
        final last = rawTracks.last;
        final nextDate = (last['dateModified'] as num?)?.toInt();
        final nextId = (last['id'] as num?)?.toInt();
        if (nextDate == null || nextId == null) {
          throw StateError('MediaStore page cursor is missing dateModified/id');
        }
        // The query is ordered DESC by (DATE_MODIFIED, ID). A full page must
        // therefore move strictly backwards. Refuse to loop forever if a
        // broken/OEM provider repeats the same boundary row.
        if (nextDate > cursorDateModifiedSeconds ||
            (nextDate == cursorDateModifiedSeconds &&
                nextId >= cursorMediaStoreId)) {
          throw StateError('MediaStore page cursor did not make progress');
        }
        cursorDateModifiedSeconds = nextDate;
        cursorMediaStoreId = nextId;
      }
    }

    final finalVolumes =
        (await PlayerChannel.instance.getMediaStoreVolumes()).toSet();
    final finalVolumeStates =
        await PlayerChannel.instance.getMediaStoreVolumeStates();
    if (currentVolumeStates.length != finalVolumeStates.length ||
        currentVolumeStates.keys.any((v) =>
            !finalVolumeStates.containsKey(v) ||
            finalVolumeStates[v]!['version'] != currentVolumeStates[v]!['version'] ||
            finalVolumeStates[v]!['generation'] != currentVolumeStates[v]!['generation'])) {
      throw StateError('MediaStore generation/version changed during scan');
    }
    // The scan must commit its cursor/volume snapshot only if the exact
    // volume set remained stable. A removed/reinserted/added volume makes
    // the snapshot incomplete; leaving the old cursor in place forces the
    // next pass to reconcile it instead of falsely marking it scanned.
    if (finalVolumes.length != currentVolumes.length ||
        !finalVolumes.containsAll(currentVolumes)) {
      throw StateError('MediaStore volume set changed during scan');
    }

    final deletedCount = await _syncDeletions(currentVolumes: finalVolumes);
    // Emit one app-level invalidation after the entire scan + deletion
    // reconciliation. Individual Isar batch transactions are intentionally
    // not exposed to UI/queue consumers, otherwise a 500k-track scan would
    // reset paging hundreds of times.
    if ((changedAny || deletedCount > 0) && !_tracksChangedController.isClosed) {
      _tracksChangedController.add(null);
    }

    // The cursor advances only to the captured upper bound. Persisting a
    // later wall-clock value would create the classic multi-volume race:
    // a track changed after its volume was queried but before the scan
    // finished could be skipped forever on the next incremental scan.
    await prefs.setInt(_lastScanKey, scanUntilMs);
    await prefs.setStringList(
      _knownMediaStoreVolumesKey,
      finalVolumes.toList()..sort(),
    );
    await prefs.setString(_mediaStoreVolumeStatesKey,
        _encodeVolumeStates(finalVolumeStates));
    if (!volumeMigrationComplete) {
      await prefs.setBool(_volumeIdentityMigrationKey, true);
    }
  }

  Future<List<Map<String, dynamic>>> _readScanPageWithEmptyRetry({
    required String volume,
    required int sinceTimestamp,
    required int untilTimestamp,
    required int cursorDateModifiedSeconds,
    required int cursorMediaStoreId,
    required int limit,
  }) async {
    // Empty is normally the terminal page, but a transient provider response
    // must never be allowed to advance the persistent cursor. Repeat the same
    // query before accepting empty as terminal. Short non-empty pages are
    // always continued by the caller.
    for (var attempt = 0; attempt < 3; attempt++) {
      final page = await PlayerChannel.instance.scanLibraryPage(
        volume: volume, sinceTimestamp: sinceTimestamp,
        untilTimestamp: untilTimestamp,
        cursorDateModifiedSeconds: cursorDateModifiedSeconds,
        cursorMediaStoreId: cursorMediaStoreId, limit: limit,
      );
      if (page.isNotEmpty || attempt == 2) return page;
    }
    return const [];
  }

  Map<String, dynamic>? _decodeVolumeState(String encoded, String volume) {
    try {
      final raw = jsonDecode(encoded);
      if (raw is! Map) return null;
      final state = raw[volume];
      return state is Map ? Map<String, dynamic>.from(state) : null;
    } catch (_) {
      return null;
    }
  }

  String _encodeVolumeStates(Map<String, Map<String, dynamic>> states) =>
      jsonEncode(states);

  Future<bool> _persistScanBatch(List<Track> tracks) async {
    var changed = false;
    await _isar.writeTxn(() async {
      // Resolve existing rows in one indexed query per volume instead of
      // issuing one Isar query for every track. The scan transaction remains
      // bounded to this batch.
      final existingByIdentity = <String, Track>{};
      final byVolume = <String, List<Track>>{};
      for (final track in tracks) {
        (byVolume[track.mediaStoreVolume] ??= <Track>[]).add(track);
      }
      for (final group in byVolume.entries) {
        final ids = group.value
            .map((t) => t.mediaStoreId)
            .toSet()
            .toList(growable: false);
        final existing = await _isar.tracks
            .filter()
            .mediaStoreVolumeEqualTo(group.key)
            .and()
            .anyOf(ids, (q, id) => q.mediaStoreIdEqualTo(id))
            .findAll();
        for (final row in existing) {
          existingByIdentity['${row.mediaStoreVolume}:${row.mediaStoreId}'] = row;
        }
      }

      for (final track in tracks) {
        final existing =
            existingByIdentity['${track.mediaStoreVolume}:${track.mediaStoreId}'];
        if (existing == null) {
          // The row will be inserted below. New rows are library mutations
          // too, so they must invalidate paging/queue consumers just like
          // metadata updates do.
          changed = true;
          continue;
        }
        track.id = existing.id;
        if (existing.dateModified == track.dateModified &&
            existing.contentUri == track.contentUri &&
            existing.durationMs == track.durationMs &&
            existing.displayName == track.displayName) {
          track.embeddedLyricsText = existing.embeddedLyricsText;
          track.lyricsChecked = existing.lyricsChecked;
          track.lyricsCheckedAtMs = existing.lyricsCheckedAtMs;
        }
        changed = changed ||
            existing.dateModified != track.dateModified ||
            existing.contentUri != track.contentUri ||
            existing.durationMs != track.durationMs ||
            existing.displayName != track.displayName ||
            existing.title != track.title ||
            existing.artist != track.artist ||
            existing.album != track.album ||
            existing.relativePath != track.relativePath ||
            existing.folder != track.folder;
      }
      if (tracks.isNotEmpty) await _isar.tracks.putAll(tracks);
    });
    return changed;
  }

  /// Diffs local Track rows against MediaStore in bounded batches.
  ///
  /// The old implementation first materialized the entire MediaStore ID
  /// set and large local ID lists. This version walks Isar by primary-key
  /// ranges and asks MediaStore only about the current batch, keeping both
  /// the platform-channel payload and Dart working sets bounded.
  Future<int> _syncDeletions({required Set<String> currentVolumes}) async {
    const candidateChunkSize = _deletionSyncChunkSize;
    var deletedCount = 0;
    var lastIsarId = 0;

    while (true) {
      // Read the identity pair from the same Track snapshot. Two independent
      // projection queries can observe different row sets between scans.
      final snapshot = await _isar.tracks
          .where()
          .idGreaterThan(lastIsarId)
          .limit(candidateChunkSize)
          .findAll();
      if (snapshot.isEmpty) break;

      // A temporarily absent removable volume is NOT a deletion. Keep its
      // rows in Isar until the volume is seen again; reappearance triggers
      // the bounded full-volume scan above. Only validate identities for
      // volumes that MediaStore currently exposes.
      final candidates = snapshot
          .where((t) => currentVolumes.contains(t.mediaStoreVolume))
          .map((t) => (t.mediaStoreVolume, t.mediaStoreId))
          .toList(growable: false);
      Set<String> existing;
      try {
        existing = await PlayerChannel.instance
            .findExistingMediaStoreIdentities(candidates);
      } catch (e) {
        // MediaStore reported an unstable volume/provider state. Never infer
        // deletion from an incomplete snapshot, and never let the outer scan
        // advance its cursor as if reconciliation succeeded. Propagate the
        // failure so the next coalesced pass retries from the old cursor.
        rethrow;
      }

      final staleIsarIds = <int>[];
      final staleIdentities = <String>[];
      final staleDateModified = <int>[];
      final staleContentUris = <String>[];
      for (var i = 0; i < snapshot.length; i++) {
        final track = snapshot[i];
        // Removable volumes that are currently absent are intentionally
        // skipped; they are unavailable, not deleted.
        if (!currentVolumes.contains(track.mediaStoreVolume)) continue;
        final key = '${track.mediaStoreVolume}:${track.mediaStoreId}';
        if (!existing.contains(key)) {
          staleIsarIds.add(track.id);
          staleIdentities.add(key);
          staleDateModified.add(track.dateModified);
          staleContentUris.add(track.contentUri);
        }
      }

      if (staleIsarIds.isNotEmpty) {
        final beforeDeleteVolumes =
            (await PlayerChannel.instance.getMediaStoreVolumes()).toSet();
        if (beforeDeleteVolumes.length != currentVolumes.length ||
            !beforeDeleteVolumes.containsAll(currentVolumes)) {
          throw StateError('MediaStore volume set changed before deletion commit');
        }
        final deletedIdentities = <String>[];
        await _isar.writeTxn(() async {
          // Re-read each candidate inside the same write transaction that
          // performs the delete. This closes the Isar-side race where a
          // candidate snapshot could otherwise become stale between the
          // MediaStore validation and deleteAll(). Identity remains the
          // volume + MediaStore ID pair; never fall back to ID-only.
          final idsToDelete = <int>[];
          for (var i = 0; i < staleIsarIds.length; i++) {
            final current = await _isar.tracks.get(staleIsarIds[i]);
            if (current == null) continue;

            final expectedIdentity = staleIdentities[i];
            final currentIdentity =
                '${current.mediaStoreVolume}:${current.mediaStoreId}';
            if (currentIdentity != expectedIdentity) continue;

            // The row may have been refreshed after the MediaStore validation
            // (for example by a later upsert). Identity alone is not enough:
            // the same volume+ID can represent a newer MediaStore version.
            // Only delete if the exact scanned version is still present.
            if (current.dateModified != staleDateModified[i]) continue;
            if (current.contentUri != staleContentUris[i]) continue;

            idsToDelete.add(current.id);
            deletedIdentities.add(expectedIdentity);
          }
          if (idsToDelete.isNotEmpty) {
            await _isar.tracks.deleteAll(idsToDelete);
          deletedCount += idsToDelete.length;
          }
        });

        if (deletedIdentities.isNotEmpty &&
            !_tracksDeletedController.isClosed) {
          _tracksDeletedController.add(deletedIdentities);
        }
      }

      lastIsarId = snapshot.last.id;
      if (snapshot.length < candidateChunkSize) break;
    }
    return deletedCount;
  }

  /// Total track count via an indexed `count()` — never loads a Track
  /// object just to size a list.
  Future<int> tracksCount() => _isar.tracks.where().count();

  /// One page of the full library, sorted by title. This — not a
  /// single `.findAll()` over the whole collection — is what backs the
  /// flat "Tracks" tab now, so it only ever holds as many rows in
  /// memory as have actually been scrolled to (see
  /// `TracksPagingNotifier` in `core/providers.dart`).
  Future<List<Track>> tracksPage({required int offset, required int limit}) =>
      _isar.tracks.where().sortByTitle().thenByMediaStoreVolume().thenByMediaStoreId().offset(offset).limit(limit).findAll();

  /// One page of indexed search results — same pagination story as
  /// [tracksPage], reusing the case-insensitive indexes already defined
  /// on [Track.title]/[Track.artist]/[Track.album] instead of an
  /// in-memory `.where()` scan over a fully materialized list.
  Future<List<Track>> searchPage(
    String query, {
    required int offset,
    required int limit,
  }) {
    return _isar.tracks
        .filter()
        .titleContains(query, caseSensitive: false)
        .or()
        .artistContains(query, caseSensitive: false)
        .or()
        .albumContains(query, caseSensitive: false)
        .sortByTitle()
        .thenByMediaStoreVolume()
        .thenByMediaStoreId()
        .offset(offset)
        .limit(limit)
        .findAll();
  }

  /// Indexed count of the same query [searchPage] pages through — used
  /// by search-context queues (FIX #2) and the windowed search pager
  /// (FIX #1) to size `ListView.builder`/report `hasMore` without
  /// loading every match into memory just to count them.
  Future<int> searchCount(String query) {
    return _isar.tracks
        .filter()
        .titleContains(query, caseSensitive: false)
        .or()
        .artistContains(query, caseSensitive: false)
        .or()
        .albumContains(query, caseSensitive: false)
        .count();
  }

  /// Fires one coalesced invalidation after repository-owned writes. Paging
  /// notifiers subscribe to this instead of Isar's raw `watchLazy()` so a
  /// large batched scan does not cause one UI reset per transaction.
  Stream<void> watchTracksChanged() => _tracksChangedController.stream;

  /// Indexed point lookup for the currently-playing MediaStore identity.
  /// The volume is part of the identity because MediaStore IDs are only
  /// unique inside a volume.
  Future<Track?> trackByMediaStoreIdentity(String volume, int id) =>
      _isar.tracks
          .filter()
          .mediaStoreVolumeEqualTo(volume)
          .and()
          .mediaStoreIdEqualTo(id)
          .findFirst();

  /// FIX #5 — BOUNDED MEMORY FOR GROUP NAME PAGING.
  ///
  /// One page of distinct, sorted group names for [field] — the
  /// database-backed replacement for the old `distinctGroupNames()`,
  /// which returned every distinct name in the library as a single
  /// `List<String>` that callers then cached wholesale in Dart
  /// (`GroupsPagingNotifier._allNames`). That list was small relative
  /// to the full `Track` table, but it was still an unbounded-with-
  /// library-size cache: a library with a very large number of
  /// distinct albums/artists/folders grew it without limit.
  ///
  /// This instead chains `sortBy<Field>()` (index-order sort) ->
  /// `distinctBy<Field>(caseSensitive: false)` (dedupe adjacent equal
  /// keys in that sorted stream) -> `.<field>Property()` (project just
  /// the String column, not full Track rows) -> `.offset()/.limit()` —
  /// all evaluated inside Isar's query engine. Isar only walks as many
  /// sorted rows as it needs to fill this page; it does not
  /// materialize the full distinct set into Dart to satisfy one page.
  /// [GroupsPagingNotifier] (see `core/providers.dart`) calls this once
  /// per page the same way [tracksPage] is called once per page of the
  /// flat Tracks tab, and relies on `WindowedPagingNotifier`'s existing
  /// bounded-page eviction to cap how many pages of names are resident
  /// at once — exactly the same mechanism already used for [Track]
  /// pages, not a second bespoke cache.
  Future<List<String>> distinctGroupNamesPage(
    GroupField field, {
    required int offset,
    required int limit,
  }) {
    return switch (field) {
      GroupField.album => _isar.tracks
          .where()
          .sortByAlbum()
          .distinctByAlbum(caseSensitive: false)
          .albumProperty()
          .offset(offset)
          .limit(limit)
          .findAll(),
      GroupField.artist => _isar.tracks
          .where()
          .sortByArtist()
          .distinctByArtist(caseSensitive: false)
          .artistProperty()
          .offset(offset)
          .limit(limit)
          .findAll(),
      GroupField.folder => _isar.tracks
          .where()
          .sortByFolder()
          .distinctByFolder(caseSensitive: true)
          .folderProperty()
          .offset(offset)
          .limit(limit)
          .findAll(),
    };
  }

  /// Total number of distinct group names for [field] — an indexed
  /// `count()` over the same distinct query [distinctGroupNamesPage]
  /// pages through, so the Albums/Artists/Folders tabs can size
  /// `ListView.builder` (`itemCount`) without ever loading a single
  /// name into memory just to count them.
  Future<int> distinctGroupNamesCount(GroupField field) {
    return switch (field) {
      GroupField.album =>
        _isar.tracks.where().distinctByAlbum(caseSensitive: false).count(),
      GroupField.artist =>
        _isar.tracks.where().distinctByArtist(caseSensitive: false).count(),
      GroupField.folder =>
        _isar.tracks.where().distinctByFolder(caseSensitive: true).count(),
    };
  }

  /// Indexed count of tracks belonging to [name] under [field] — a
  /// single index-backed `count()` query, no rows deserialized.
  Future<int> countForGroup(GroupField field, String name) {
    return switch (field) {
      GroupField.album =>
        _isar.tracks.filter().albumEqualTo(name, caseSensitive: false).count(),
      GroupField.artist => _isar.tracks
          .filter()
          .artistEqualTo(name, caseSensitive: false)
          .count(),
      GroupField.folder => _isar.tracks
          .filter()
          .folderEqualTo(name, caseSensitive: true)
          .count(),
    };
  }

  /// FIX #3 — BATCHED GROUP COUNTS FOR A PAGE OF GROUP NAMES.
  ///
  /// Given one page of distinct group [names] (as returned by
  /// [distinctGroupNamesPage]), resolves every name's track count with
  /// exactly ONE additional Isar query — replacing the previous
  /// per-name `Future.wait(pageNames.map(countForGroup))` pattern in
  /// `GroupsPagingNotifier.fetchPage`, which issued one `count()` query
  /// per group (≈60 extra queries for a 60-name page, ~61 total).
  ///
  /// Isar 3.x has no native `GROUP BY ... COUNT(*)` for this query. This
  /// therefore uses one `.anyOf()` predicate for the whole page and walks
  /// matching rows by primary-key ranges. Only a fixed-size chunk of Track
  /// objects is materialized at a time; unlike the earlier OFFSET-based
  /// projection, the database does not repeatedly traverse an ever-growing
  /// skipped prefix for each chunk.
  ///
  /// Matches [countForGroup]'s case-insensitive equality semantics: a
  /// name's count includes every track whose [field] value matches that
  /// name case-insensitively, exactly like calling [countForGroup] once
  /// per name would. Returns 0 for a name with no matches rather than
  /// omitting it, so callers can always safely index the result by the
  /// exact name they passed in.
  Future<Map<String, int>> countsForGroups(
    GroupField field,
    List<String> names,
  ) async {
    if (names.isEmpty) return const {};

    // Isar 3.x does not expose a native GROUP BY COUNT(*) for this query.
    // Keep one batched predicate for the whole page, but walk the matching
    // rows by primary-key ranges rather than repeatedly using OFFSET. OFFSET
    // can force the database to traverse the already-skipped rows again for
    // every chunk, which becomes increasingly expensive for very large
    // groups. Only one bounded chunk of Track objects is materialized at a
    // time, so memory remains proportional to chunkSize rather than the
    // number of matching tracks.
    const chunkSize = 4096;

    final counts = <String, int>{for (final n in names) n: 0};
    final normalizedToOriginal = <String, String>{};
    for (final n in names) {
      final key = field == GroupField.folder ? n : n.toLowerCase();
      normalizedToOriginal[key] = n;
    }

    Future<List<Track>> readChunk(int lastId) {
      return switch (field) {
        GroupField.album => _isar.tracks
            .where()
            .idGreaterThan(lastId)
            .filter()
            .anyOf(names, (q, name) => q.albumEqualTo(name, caseSensitive: false))
            .limit(chunkSize)
            .findAll(),
        GroupField.artist => _isar.tracks
            .where()
            .idGreaterThan(lastId)
            .filter()
            .anyOf(names, (q, name) => q.artistEqualTo(name, caseSensitive: false))
            .limit(chunkSize)
            .findAll(),
        GroupField.folder => _isar.tracks
            .where()
            .idGreaterThan(lastId)
            .filter()
            .anyOf(names, (q, name) => q.folderEqualTo(name, caseSensitive: true))
            .limit(chunkSize)
            .findAll(),
      };
    }

    var lastId = 0;
    while (true) {
      final tracks = await readChunk(lastId);
      if (tracks.isEmpty) break;

      for (final track in tracks) {
        final value = switch (field) {
          GroupField.album => track.album,
          GroupField.artist => track.artist,
          GroupField.folder => track.folder,
        };
        final key = field == GroupField.folder ? value : value.toLowerCase();
        final original = normalizedToOriginal[key];
        if (original != null) counts[original] = counts[original]! + 1;
      }

      lastId = tracks.last.id;
      if (tracks.length < chunkSize) break;
    }

    // Dart lower-casing is not a guaranteed implementation of Isar's
    // case-insensitive Unicode equality. For non-ASCII names, replace the
    // batched approximation with the database's own comparator. This keeps
    // the common ASCII path batched while making international group counts
    // exactly match `*EqualTo(..., caseSensitive: false)`.
    final unicodeNames = names.where((name) =>
        field != GroupField.folder && name.codeUnits.any((c) => c > 0x7f));
    for (final name in unicodeNames) {
      final exactCount = switch (field) {
        GroupField.album => await _isar.tracks
            .filter()
            .albumEqualTo(name, caseSensitive: false)
            .count(),
        GroupField.artist => await _isar.tracks
            .filter()
            .artistEqualTo(name, caseSensitive: false)
            .count(),
        GroupField.folder => 0,
      };
      counts[name] = exactCount;
    }

    return counts;
  }

  /// One page of tracks belonging to [name] under [field], sorted by
  /// title. Loaded lazily — only once a group is actually expanded in
  /// the UI — and only [limit] rows at a time, so expanding many groups
  /// in a large library never holds every member track of every group
  /// in memory at once.
  Future<List<Track>> tracksForGroupPage(
    GroupField field,
    String name, {
    required int offset,
    required int limit,
  }) {
    return switch (field) {
      GroupField.album => _isar.tracks
          .filter()
          .albumEqualTo(name, caseSensitive: false)
          .sortByTitle()
          .thenByMediaStoreVolume()
          .thenByMediaStoreId()
          .offset(offset)
          .limit(limit)
          .findAll(),
      GroupField.artist => _isar.tracks
          .filter()
          .artistEqualTo(name, caseSensitive: false)
          .sortByTitle()
          .thenByMediaStoreVolume()
          .thenByMediaStoreId()
          .offset(offset)
          .limit(limit)
          .findAll(),
      GroupField.folder => _isar.tracks
          .filter()
          .folderEqualTo(name, caseSensitive: true)
          .sortByTitle()
          .thenByMediaStoreVolume()
          .thenByMediaStoreId()
          .offset(offset)
          .limit(limit)
          .findAll(),
    };
  }

  /// Returns the zero-based position of a MediaStore identity in the same
  /// deterministic order used by [tracksPage]. The secondary keys make
  /// duplicate titles stable, which is important when a queue is rebased
  /// after a library mutation.
  /// Returns the zero-based position of a MediaStore identity in the same
  /// deterministic title/volume/id order used by [tracksPage]. The title
  /// index is used for the large leading range; the smaller tie-break ranges
  /// are evaluated only inside the matching title range. This avoids the
  /// previous single full-collection `.filter().count()` for the common
  /// all-tracks/group position paths.
  Future<int?> allTracksPosition(String volume, int mediaStoreId) async {
    final current = await trackByMediaStoreIdentity(volume, mediaStoreId);
    if (current == null) return null;

    final titleBefore = await _isar.tracks
        .where()
        .titleLessThan(current.title, caseSensitive: false)
        .count();

    final sameTitleVolumeBefore = await _isar.tracks
        .where()
        .titleEqualTo(current.title, caseSensitive: false)
        .filter()
        .mediaStoreVolumeLessThan(current.mediaStoreVolume)
        .count();

    final sameTitleSameVolumeIdBefore = await _isar.tracks
        .where()
        .titleEqualTo(current.title, caseSensitive: false)
        .filter()
        .mediaStoreVolumeEqualTo(current.mediaStoreVolume)
        .and()
        .mediaStoreIdLessThan(current.mediaStoreId)
        .count();

    return titleBefore + sameTitleVolumeBefore + sameTitleSameVolumeIdBefore;
  }

  Future<int?> searchPosition(
    String query,
    String volume,
    int mediaStoreId,
  ) async {
    final current = await trackByMediaStoreIdentity(volume, mediaStoreId);
    if (current == null) return null;

    final matchesCurrent = await _isar.tracks
        .filter()
        .mediaStoreVolumeEqualTo(volume)
        .and()
        .mediaStoreIdEqualTo(mediaStoreId)
        .and()
        .group((q) => q
            .titleContains(query, caseSensitive: false)
            .or()
            .artistContains(query, caseSensitive: false)
            .or()
            .albumContains(query, caseSensitive: false))
        .count();
    if (matchesCurrent == 0) return null;

    final titleBefore = await _isar.tracks
        .where()
        .titleLessThan(current.title, caseSensitive: false)
        .filter()
        .group((q) => q
            .titleContains(query, caseSensitive: false)
            .or()
            .artistContains(query, caseSensitive: false)
            .or()
            .albumContains(query, caseSensitive: false))
        .count();

    final sameTitleVolumeBefore = await _isar.tracks
        .where()
        .titleEqualTo(current.title, caseSensitive: false)
        .filter()
        .mediaStoreVolumeLessThan(current.mediaStoreVolume)
        .and()
        .group((q) => q
            .titleContains(query, caseSensitive: false)
            .or()
            .artistContains(query, caseSensitive: false)
            .or()
            .albumContains(query, caseSensitive: false))
        .count();

    final sameTitleSameVolumeIdBefore = await _isar.tracks
        .where()
        .titleEqualTo(current.title, caseSensitive: false)
        .filter()
        .mediaStoreVolumeEqualTo(current.mediaStoreVolume)
        .and()
        .mediaStoreIdLessThan(current.mediaStoreId)
        .and()
        .group((q) => q
            .titleContains(query, caseSensitive: false)
            .or()
            .artistContains(query, caseSensitive: false)
            .or()
            .albumContains(query, caseSensitive: false))
        .count();

    return titleBefore + sameTitleVolumeBefore + sameTitleSameVolumeIdBefore;
  }

  Future<int?> groupPosition(
    GroupField field,
    String name,
    String volume,
    int mediaStoreId,
  ) async {
    final current = await trackByMediaStoreIdentity(volume, mediaStoreId);
    if (current == null) return null;

    final matchesCurrent = switch (field) {
      GroupField.album => await _isar.tracks
          .filter()
          .mediaStoreVolumeEqualTo(volume)
          .and()
          .mediaStoreIdEqualTo(mediaStoreId)
          .and()
          .albumEqualTo(name, caseSensitive: false)
          .count(),
      GroupField.artist => await _isar.tracks
          .filter()
          .mediaStoreVolumeEqualTo(volume)
          .and()
          .mediaStoreIdEqualTo(mediaStoreId)
          .and()
          .artistEqualTo(name, caseSensitive: false)
          .count(),
      GroupField.folder => await _isar.tracks
          .filter()
          .mediaStoreVolumeEqualTo(volume)
          .and()
          .mediaStoreIdEqualTo(mediaStoreId)
          .and()
          .folderEqualTo(name, caseSensitive: true)
          .count(),
    };
    if (matchesCurrent == 0) return null;

    Future<int> countBeforeWithGroup() async {
      final titleBefore = switch (field) {
        GroupField.album => await _isar.tracks
            .where()
            .titleLessThan(current.title, caseSensitive: false)
            .filter()
            .albumEqualTo(name, caseSensitive: false)
            .count(),
        GroupField.artist => await _isar.tracks
            .where()
            .titleLessThan(current.title, caseSensitive: false)
            .filter()
            .artistEqualTo(name, caseSensitive: false)
            .count(),
        GroupField.folder => await _isar.tracks
            .where()
            .titleLessThan(current.title, caseSensitive: false)
            .filter()
            .folderEqualTo(name, caseSensitive: true)
            .count(),
      };

      final sameTitleVolumeBefore = switch (field) {
        GroupField.album => await _isar.tracks
            .where()
            .titleEqualTo(current.title, caseSensitive: false)
            .filter()
            .mediaStoreVolumeLessThan(current.mediaStoreVolume)
            .and()
            .albumEqualTo(name, caseSensitive: false)
            .count(),
        GroupField.artist => await _isar.tracks
            .where()
            .titleEqualTo(current.title, caseSensitive: false)
            .filter()
            .mediaStoreVolumeLessThan(current.mediaStoreVolume)
            .and()
            .artistEqualTo(name, caseSensitive: false)
            .count(),
        GroupField.folder => await _isar.tracks
            .where()
            .titleEqualTo(current.title, caseSensitive: false)
            .filter()
            .mediaStoreVolumeLessThan(current.mediaStoreVolume)
            .and()
            .folderEqualTo(name, caseSensitive: true)
            .count(),
      };

      final sameTitleSameVolumeIdBefore = switch (field) {
        GroupField.album => await _isar.tracks
            .where()
            .titleEqualTo(current.title, caseSensitive: false)
            .filter()
            .mediaStoreVolumeEqualTo(current.mediaStoreVolume)
            .and()
            .mediaStoreIdLessThan(current.mediaStoreId)
            .and()
            .albumEqualTo(name, caseSensitive: false)
            .count(),
        GroupField.artist => await _isar.tracks
            .where()
            .titleEqualTo(current.title, caseSensitive: false)
            .filter()
            .mediaStoreVolumeEqualTo(current.mediaStoreVolume)
            .and()
            .mediaStoreIdLessThan(current.mediaStoreId)
            .and()
            .artistEqualTo(name, caseSensitive: false)
            .count(),
        GroupField.folder => await _isar.tracks
            .where()
            .titleEqualTo(current.title, caseSensitive: false)
            .filter()
            .mediaStoreVolumeEqualTo(current.mediaStoreVolume)
            .and()
            .mediaStoreIdLessThan(current.mediaStoreId)
            .and()
            .folderEqualTo(name, caseSensitive: true)
            .count(),
      };

      return titleBefore + sameTitleVolumeBefore + sameTitleSameVolumeIdBefore;
    }

    return countBeforeWithGroup();
  }

  /// Resolves and returns lyrics text for [track], caching it on the
  /// record so re-opening the lyrics view for the same track skips the
  /// native lookup entirely.
  ///
  /// Tries [track]'s embedded tags first (ID3 USLT/COMM, a Vorbis
  /// "LYRICS"/"UNSYNCEDLYRICS" comment, or the MP4 "©lyr" atom), then
  /// falls back to a sidecar `.lrc` file in the same folder — see
  /// `PlayerChannel.getLyrics` / native `SidecarLyricsResolver` for how
  /// that fallback stays correct under Android 13+ Scoped Storage.
  ///
  /// Returns null if neither source has lyrics for this track. The
  /// returned text may itself be `.lrc`-formatted — callers should run
  /// it through `LrcParser.parse` and fall back to a plain-text display
  /// if that yields no timed lines (see `LyricsScreen`).
  ///
  /// Both positive and negative lyrics results are cached briefly. A sidecar
  /// `.lrc` can be created or edited without changing the audio file's
  /// MediaStore timestamp, so a permanent positive cache would otherwise
  /// serve stale sidecar lyrics indefinitely. The short TTL bounds that
  /// staleness while still avoiding repeated metadata/SAF work on every view.
  static const _lyricsCacheTtl = Duration(minutes: 2);

  Future<String?> ensureLyrics(Track track, {bool forceRefresh = false}) {
    final key = '${track.mediaStoreVolume}:${track.mediaStoreId}:${track.dateModified}:${track.contentUri}:${track.durationMs}:${track.displayName}';
    final inFlight = _lyricsInFlight[key];
    if (inFlight != null) return inFlight;

    // Force-refresh bypasses the cached value, but still joins an already
    // running lookup for the same immutable track version. This prevents two
    // concurrent metadata/SAF reads where the older result could overwrite
    // the fresher one.
    final future = _ensureLyricsInternal(track, forceRefresh: forceRefresh);
    _lyricsInFlight[key] = future;
    future.then(
      (_) => _lyricsInFlight.remove(key),
      onError: (Object _, StackTrace __) => _lyricsInFlight.remove(key),
    );
    return future;
  }

  Future<String?> _ensureLyricsInternal(Track track, {required bool forceRefresh}) async {
    final cached = track.embeddedLyricsText;
    final nowMs = DateTime.now().millisecondsSinceEpoch;
    final cacheIsFresh = track.lyricsChecked &&
        track.lyricsCheckedAtMs > 0 &&
        nowMs >= track.lyricsCheckedAtMs &&
        nowMs - track.lyricsCheckedAtMs < _lyricsCacheTtl.inMilliseconds;
    if (!forceRefresh && cacheIsFresh) return cached;

    final text = await PlayerChannel.instance.getLyrics(
      track.contentUri,
      mediaStoreVolume: track.mediaStoreVolume,
      relativePath: track.relativePath,
      displayName: track.displayName,
    );

    await _isar.writeTxn(() async {
      final current = await _isar.tracks
          .filter()
          .mediaStoreVolumeEqualTo(track.mediaStoreVolume)
          .and()
          .mediaStoreIdEqualTo(track.mediaStoreId)
          .findFirst();
      if (current == null ||
          current.dateModified != track.dateModified ||
          current.contentUri != track.contentUri ||
          current.durationMs != track.durationMs ||
          current.displayName != track.displayName) {
        return;
      }
      current.embeddedLyricsText = text;
      current.lyricsChecked = true;
      current.lyricsCheckedAtMs = nowMs;
      await _isar.tracks.put(current);
    });
    return text;
  }
}
