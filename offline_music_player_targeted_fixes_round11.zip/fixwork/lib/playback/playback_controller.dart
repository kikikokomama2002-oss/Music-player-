import 'dart:async';
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../core/providers.dart';
import '../data/repositories/library_repository.dart';
import 'player_channel.dart';
import 'playback_state.dart';
import 'queue_spec.dart';

/// Number of tracks fetched on either side of the tapped track for a
/// new queue's initial native window (FIX #2). Skewed forward (most
/// listening moves forward via Next / natural playback) while still
/// giving Previous some immediate headroom without a round-trip.
const _initialWindowBefore = 20;
const _initialWindowAfter = 80;
const _savedQueueSpecKey = 'active_queue_spec_v1';
const _savedQueueContextIdKey = 'active_queue_context_id_v1';
const _pendingQueueSpecKey = 'pending_queue_spec_v1';
const _pendingQueueContextIdKey = 'pending_queue_context_id_v1';
const _savedQueueAtKey = 'active_queue_saved_at_ms_v1';
const _queueRestoreMaxAge = Duration(hours: 24);

/// Owns the live [PlaybackState] and exposes high-level transport intents
/// (playQueue, togglePlayPause, seek, next, previous) used by the UI.
/// Listens to the native EventChannel stream and republishes state
/// updates into Riverpod so any widget can watch it.
///
/// FIX #2 — QUERY-BACKED PLAYBACK QUEUE:
///
/// [playQueue] no longer takes a `List<Track>` — it takes a [QueueSpec]
/// (the query the track was tapped from: all tracks / a search / one
/// album-artist-folder group) plus a logical [startIndex] into that
/// query's full, ordered result set. Only a small initial window of
/// [Track]s around [startIndex] is ever sent to native — see
/// `PlayerChannel.setQueueContext`.
///
/// As the native sliding-window queue controller (Kotlin `PlayerHolder`)
/// plays toward either edge of what it's been given, it calls back into
/// Dart via [PlayerChannel.setNativeCallHandler]'s `requestQueuePage`,
/// which [_handleNativeCall] resolves by re-running [QueueSpec.resolvePage]
/// against the CURRENT [_activeSpec] — the same indexed
/// `offset().limit()` Isar query the windowed UI pagers use, not a
/// second copy of the library held anywhere in Dart. A 10,000-track
/// "all tracks" queue therefore costs Dart the same handful of
/// resident [Track] objects as a 60-track one, exactly like the UI
/// list itself.
class PlaybackController extends StateNotifier<PlaybackState> {
  PlaybackController(this._ref) : super(const PlaybackState()) {
    _sub = PlayerChannel.instance.stateStream.listen((s) => state = s);
    PlayerChannel.instance.setNativeCallHandler(_handleNativeCall);
    // libraryRepositoryProvider depends on isarProvider's async open, so
    // it may still be null at construction time — watch for it to
    // become available rather than reading it once, same reasoning as
    // the paging notifiers in core/providers.dart.
    _ref.listen<LibraryRepository?>(
      libraryRepositoryProvider,
      (previous, next) {
        if (next == null || previous != null) return;
        _deletionsSub = next.tracksDeleted.listen(_onTracksDeleted);
        _changesSub = next.tracksChanged.listen((_) => _onTracksChanged());
        unawaited(_restoreQueueContext());
      },
      fireImmediately: true,
    );
  }

  final Ref _ref;
  late final StreamSubscription<PlaybackState> _sub;
  StreamSubscription<List<String>>? _deletionsSub;
  StreamSubscription<void>? _changesSub;

  QueueSpec? _activeSpec;
  int _contextCounter = 0;
  int _playQueueGeneration = 0;
  String? _activeContextId;

  /// FIX #4 — request ids (from native's `requestId` arg — see
  /// `MethodChannelQueuePageProvider`) currently being handled by
  /// [_handleNativeCall]'s `requestQueuePage` case. Only ever holds ids
  /// for genuinely in-flight requests — added right before the DB
  /// query starts, removed in a `finally` once it finishes — so a
  /// `cancelQueuePage` notice that arrives for an id NOT in here (the
  /// matching request already finished, or — impossible in practice
  /// given the two calls share one ordered channel — hasn't arrived
  /// yet) is simply dropped rather than remembered forever. This is
  /// what keeps [_cancelledRequestIds] bounded.
  final Set<int> _pendingRequestIds = {};

  /// Ids from [_pendingRequestIds] that received a `cancelQueuePage`
  /// notice while still in flight — checked once the DB read finishes
  /// so a cancelled request can skip its second query and building a
  /// result payload nothing on the native side will read (see
  /// `MethodChannelQueuePageProvider.requestPage`'s
  /// `invokeOnCancellation`). Isar's `findAll()` can't be aborted
  /// mid-query, so this can't skip work already started, only work not
  /// yet done.
  final Set<int> _cancelledRequestIds = {};

  LibraryRepository? get _repo => _ref.read(libraryRepositoryProvider);

  /// Establishes [spec] (all tracks / a search / one group) as the
  /// active queue and starts playback at its logical [startIndex] —
  /// see class doc for how native gets the rest of the queue without
  /// Dart ever holding [spec]'s complete track list.
  Future<void> playQueue(
    QueueSpec spec, {
    required int startIndex,
    required String startVolume,
    required int startMediaStoreId,
  }) async {
    final requestGeneration = ++_playQueueGeneration;
    final repo = _repo;
    if (repo == null) return;

    List<Map<String, dynamic>> window = const [];
    var totalCount = 0;
    var clampedStart = 0;
    var windowStart = 0;

    // The UI index is only a hint: the tapped Track identity is stable even
    // if inserts/deletes happen while the async count/page calls are running.
    // Resolve the position again immediately before loading the initial window
    // and verify that the returned window still contains that identity. A
    // bounded retry handles a mutation occurring between those two queries.
    for (var attempt = 0; attempt < 3; attempt++) {
      totalCount = await spec.resolveCount(repo);
      if (requestGeneration != _playQueueGeneration) return;
      if (totalCount == 0) return;
      final resolvedPosition = await spec.resolvePosition(
        repo,
        volume: startVolume,
        mediaStoreId: startMediaStoreId,
      );
      if (requestGeneration != _playQueueGeneration) return;
      if (resolvedPosition == null) return;
      clampedStart = resolvedPosition.clamp(0, totalCount - 1).toInt();
      windowStart =
          (clampedStart - _initialWindowBefore).clamp(0, totalCount - 1).toInt();
      final windowEnd =
          (clampedStart + _initialWindowAfter + 1).clamp(0, totalCount).toInt();
      final candidate = await spec.resolvePage(
        repo,
        offset: windowStart,
        limit: windowEnd - windowStart,
      );
      if (requestGeneration != _playQueueGeneration) return;

      // The count query and page query are separate Isar operations. If the
      // library changed between them, do not install a window paired with an
      // obsolete logical count. A bounded retry re-resolves position/page
      // against the newer dataset.
      final verifiedCount = await spec.resolveCount(repo);
      if (requestGeneration != _playQueueGeneration) return;
      if (verifiedCount != totalCount) {
        totalCount = verifiedCount;
        if (totalCount <= 0) return;
        continue;
      }

      final targetOffset = clampedStart - windowStart;
      if (targetOffset >= 0 && targetOffset < candidate.length) {
        final target = candidate[targetOffset];
        final targetVolume = target['volume'] as String?;
        final targetId = (target['id'] as num?)?.toInt();
        if (targetVolume == startVolume && targetId == startMediaStoreId) {
          window = candidate;
          break;
        }
      }
      if (attempt == 2) return;
    }
    if (window.isEmpty) return;

    _contextCounter++;
    final contextId = 'q$_contextCounter';
    final prefs = await SharedPreferences.getInstance();

    // Two-phase persistence closes the crash window between native queue
    // installation and SharedPreferences. If the process dies before the
    // commit, startup can tell whether the pending spec belongs to the
    // native context that actually survived.
    await prefs.setString(_pendingQueueSpecKey, jsonEncode(spec.toMap()));
    await prefs.setString(_pendingQueueContextIdKey, contextId);

    try {
      await PlayerChannel.instance.setQueueContext(
        contextId: contextId,
        spec: spec.toMap(),
        totalCount: totalCount,
        startIndex: clampedStart,
        initialWindow: window,
        windowStartIndex: windowStart,
        startItemIdentity: '$startVolume:$startMediaStoreId',
      );
    } catch (_) {
      await prefs.remove(_pendingQueueSpecKey);
      await prefs.remove(_pendingQueueContextIdKey);
      rethrow;
    }

    _activeSpec = spec;
    _activeContextId = contextId;
    await prefs.setString(_savedQueueSpecKey, jsonEncode(spec.toMap()));
    await prefs.setString(_savedQueueContextIdKey, contextId);
    await prefs.setInt(_savedQueueAtKey, DateTime.now().millisecondsSinceEpoch);
    await prefs.remove(_pendingQueueSpecKey);
    await prefs.remove(_pendingQueueContextIdKey);
  }

  Future<void> _restoreQueueContext() async {
    final prefs = await SharedPreferences.getInstance();
    if (_activeContextId != null) return;

    final savedAt = prefs.getInt(_savedQueueAtKey);
    if (savedAt != null &&
        DateTime.now().millisecondsSinceEpoch - savedAt >
            _queueRestoreMaxAge.inMilliseconds) {
      await prefs.remove(_savedQueueSpecKey);
      await prefs.remove(_savedQueueContextIdKey);
      await prefs.remove(_savedQueueAtKey);
      await prefs.remove(_pendingQueueSpecKey);
      await prefs.remove(_pendingQueueContextIdKey);
      return;
    }

    final nativeContextId = await PlayerChannel.instance.getQueueContextId();
    final pendingContext = prefs.getString(_pendingQueueContextIdKey);
    final pendingSpec = prefs.getString(_pendingQueueSpecKey);
    final savedContext = prefs.getString(_savedQueueContextIdKey);
    final savedSpec = prefs.getString(_savedQueueSpecKey);

    // Native queue survived: reconnect Dart to the exact surviving context.
    if (nativeContextId != null && nativeContextId.isNotEmpty) {
      String? encoded;
      if (pendingContext == nativeContextId && pendingSpec != null) {
        encoded = pendingSpec;
        await prefs.setString(_savedQueueSpecKey, pendingSpec);
        await prefs.setString(_savedQueueContextIdKey, nativeContextId);
        await prefs.setInt(_savedQueueAtKey, DateTime.now().millisecondsSinceEpoch);
        await prefs.remove(_pendingQueueSpecKey);
        await prefs.remove(_pendingQueueContextIdKey);
      } else if (savedContext == nativeContextId && savedSpec != null) {
        encoded = savedSpec;
      } else {
        await prefs.remove(_pendingQueueSpecKey);
        await prefs.remove(_pendingQueueContextIdKey);
        return;
      }

      try {
        final decoded = jsonDecode(encoded);
        if (decoded is! Map) return;
        final spec = QueueSpec.fromMap(decoded);
        final repo = _repo;
        if (spec == null || repo == null) return;
        final currentCount = await spec.resolveCount(repo);
        if (currentCount > 0) {
          final firstPage = await spec.resolvePage(repo, offset: 0, limit: 1);
          if (firstPage.isEmpty) return;
        }
        final suffix = int.tryParse(
          nativeContextId.startsWith('q') ? nativeContextId.substring(1) : '',
        );
        if (suffix != null && suffix > _contextCounter) _contextCounter = suffix;
        _activeSpec = spec;
        _activeContextId = nativeContextId;
      } catch (_) {
        await prefs.remove(_savedQueueSpecKey);
        await prefs.remove(_savedQueueContextIdKey);
      }
      return;
    }

    // Native queue is gone, but a valid persisted logical descriptor remains.
    // Reconstruct a fresh bounded native window instead of silently discarding
    // the saved queue. Start at logical index 0 because native playback
    // position cannot survive a destroyed ExoPlayer instance.
    final encoded = pendingSpec ?? savedSpec;
    if (encoded == null) return;
    final repo = _repo;
    if (repo == null) return;

    try {
      final decoded = jsonDecode(encoded);
      if (decoded is! Map) return;
      final spec = QueueSpec.fromMap(decoded);
      if (spec == null) return;
      final totalCount = await spec.resolveCount(repo);
      if (totalCount <= 0) {
        await prefs.remove(_savedQueueSpecKey);
        await prefs.remove(_savedQueueContextIdKey);
        await prefs.remove(_savedQueueAtKey);
        return;
      }
      final limit = totalCount.clamp(1, _initialWindowAfter + 1).toInt();
      final window = await spec.resolvePage(repo, offset: 0, limit: limit);
      if (window.isEmpty) return;
      final first = window.first;
      final startVolume = first['volume'] as String?;
      final startId = (first['id'] as num?)?.toInt();
      if (startVolume == null || startId == null) return;

      _contextCounter++;
      final newContextId = 'q$_contextCounter';
      await PlayerChannel.instance.setQueueContext(
        contextId: newContextId,
        spec: spec.toMap(),
        totalCount: totalCount,
        startIndex: 0,
        initialWindow: window,
        windowStartIndex: 0,
        startItemIdentity: '$startVolume:$startId',
      );
      _activeSpec = spec;
      _activeContextId = newContextId;
      await prefs.setString(_savedQueueSpecKey, jsonEncode(spec.toMap()));
      await prefs.setString(_savedQueueContextIdKey, newContextId);
      await prefs.setInt(_savedQueueAtKey, DateTime.now().millisecondsSinceEpoch);
      await prefs.remove(_pendingQueueSpecKey);
      await prefs.remove(_pendingQueueContextIdKey);
    } catch (_) {
      // Keep the persisted descriptor for a later retry; a failed native
      // reconstruction must never turn a valid saved queue into success.
    }
  }

  /// Handles native→Dart calls from the sliding-window queue controller:
  /// `requestQueuePage`, made when playback nears either edge of the
  /// currently loaded native window and needs more of [_activeSpec]'s
  /// logical result set, and `cancelQueuePage` (FIX #4), a
  /// fire-and-forget notice that a previously made `requestQueuePage`
  /// call is no longer wanted because the native coroutine awaiting it
  /// was cancelled.
  Future<dynamic> _handleNativeCall(MethodCall call) async {
    switch (call.method) {
      case 'mediaStoreChanged':
        final repo = _repo;
        if (repo != null) {
          unawaited(repo.scanAndPersist());
        }
        return null;

      case 'requestQueuePage':
        final args = (call.arguments as Map).cast<String, dynamic>();
        final contextId = args['contextId'] as String?;
        final offset = (args['offset'] as num?)?.toInt() ?? 0;
        final limit = (args['limit'] as num?)?.toInt() ?? 0;
        final requestId = (args['requestId'] as num?)?.toInt();
        if (offset < 0 || limit <= 0 || limit > 240) {
          return {'items': const <Map<String, dynamic>>[], 'totalCount': 0, 'startIndex': offset};
        }

        // A response for a queue that's since been replaced — the
        // native side already discards these by contextId too, but
        // avoid doing a wasted DB query for it here as well.
        if (contextId != _activeContextId || _activeSpec == null) {
          return {'items': const <Map<String, dynamic>>[], 'totalCount': 0};
        }
        final repo = _repo;
        if (repo == null) {
          return {'items': const <Map<String, dynamic>>[], 'totalCount': 0};
        }

        if (requestId != null) _pendingRequestIds.add(requestId);
        try {
          final spec = _activeSpec!;
          // Isar does not expose a snapshot spanning multiple async query
          // calls. Read the page twice and only return it when the ordered
          // identity span is stable across both reads. This closes the
          // remaining window where an insert/delete/re-sort between a page
          // query and the native append could otherwise shift the logical
          // offset without necessarily overlapping the loaded window.
          for (var attempt = 0; attempt < 2; attempt++) {
            final requestLibraryGeneration = repo.libraryGeneration;
            final page =
                await spec.resolvePage(repo, offset: offset, limit: limit);

            if (requestId != null && _cancelledRequestIds.contains(requestId)) {
              return {'items': const <Map<String, dynamic>>[], 'totalCount': 0};
            }

            final totalCount = await spec.resolveCount(repo);
            if (totalCount < offset) {
              if (attempt == 1) {
                return {'items': const <Map<String, dynamic>>[], 'totalCount': totalCount, 'startIndex': offset};
              }
              continue;
            }

            final verification =
                await spec.resolvePage(repo, offset: offset, limit: limit);
            if (requestId != null && _cancelledRequestIds.contains(requestId)) {
              return {'items': const <Map<String, dynamic>>[], 'totalCount': totalCount, 'startIndex': offset};
            }

            bool sameIdentitySpan(
              List<Map<String, dynamic>> a,
              List<Map<String, dynamic>> b,
            ) {
              if (a.length != b.length) return false;
              for (var i = 0; i < a.length; i++) {
                if (a[i]['volume'] != b[i]['volume'] ||
                    a[i]['id'] != b[i]['id']) {
                  return false;
                }
              }
              return true;
            }

            if (sameIdentitySpan(page, verification) &&
                requestLibraryGeneration == repo.libraryGeneration) {
              return {
                'items': verification,
                'totalCount': totalCount,
                'startIndex': offset,
              };
            }
          }

          return {'items': const <Map<String, dynamic>>[], 'totalCount': 0, 'startIndex': offset};
        } finally {
          if (requestId != null) {
            _pendingRequestIds.remove(requestId);
            _cancelledRequestIds.remove(requestId);
          }
        }

      case 'requestQueuePageAround':
        final args = (call.arguments as Map).cast<String, dynamic>();
        final contextId = args['contextId'] as String?;
        final volume = args['volume'] as String?;
        final mediaStoreId = (args['id'] as num?)?.toInt();
        final before = ((args['before'] as num?)?.toInt() ?? 20).clamp(0, 80).toInt();
        final after = ((args['after'] as num?)?.toInt() ?? 120).clamp(1, 160).toInt();
        final requestId = (args['requestId'] as num?)?.toInt();
        if (contextId != _activeContextId ||
            _activeSpec == null ||
            volume == null ||
            mediaStoreId == null) {
          return {'items': const <Map<String, dynamic>>[], 'totalCount': 0, 'startIndex': 0};
        }
        final repo = _repo;
        if (repo == null) {
          return {'items': const <Map<String, dynamic>>[], 'totalCount': 0, 'startIndex': 0};
        }
        if (requestId != null) _pendingRequestIds.add(requestId);
        try {
          final spec = _activeSpec!;
          final targetIdentity = '$volume:$mediaStoreId';
          // Position, count and page are separate Isar operations. The
          // library can mutate between any two of them, so never hand native
          // a page merely because the old position query succeeded. Verify
          // that the exact identity is still at the expected logical slot.
          // A bounded retry turns a concurrent scan/delete into a harmless
          // re-resolution instead of a stale queue window.
          for (var attempt = 0; attempt < 3; attempt++) {
            final requestLibraryGeneration = repo.libraryGeneration;
            final position = await spec.resolvePosition(
              repo,
              volume: volume,
              mediaStoreId: mediaStoreId,
            );
            if (position == null) {
              return {'items': const <Map<String, dynamic>>[], 'totalCount': 0, 'startIndex': 0};
            }
            if (requestId != null && _cancelledRequestIds.contains(requestId)) {
              return {'items': const <Map<String, dynamic>>[], 'totalCount': 0, 'startIndex': position};
            }

            final totalCount = await spec.resolveCount(repo);
            if (totalCount <= 0 || position >= totalCount) {
              if (attempt == 2) {
                return {'items': const <Map<String, dynamic>>[], 'totalCount': totalCount, 'startIndex': 0};
              }
              continue;
            }

            final start = (position - before).clamp(0, totalCount - 1).toInt();
            final limit = (before + after + 1).clamp(1, 240).toInt();
            final page = await spec.resolvePage(repo, offset: start, limit: limit);
            if (requestId != null && _cancelledRequestIds.contains(requestId)) {
              return {'items': const <Map<String, dynamic>>[], 'totalCount': totalCount, 'startIndex': start};
            }

            final relative = position - start;
            final item = relative >= 0 && relative < page.length ? page[relative] : null;
            final itemIdentity = item == null
                ? null
                : '${item['volume'] as String?}:${(item['id'] as num?)?.toInt()}';
            if (itemIdentity == targetIdentity &&
                requestLibraryGeneration == repo.libraryGeneration) {
              return {'items': page, 'totalCount': totalCount, 'startIndex': start};
            }

            if (attempt == 2) {
              return {'items': const <Map<String, dynamic>>[], 'totalCount': totalCount, 'startIndex': start};
            }
          }
          return {'items': const <Map<String, dynamic>>[], 'totalCount': 0, 'startIndex': 0};
        } finally {
          if (requestId != null) {
            _pendingRequestIds.remove(requestId);
            _cancelledRequestIds.remove(requestId);
          }
        }

      case 'cancelQueuePage':
        // Fire-and-forget notice that the native coroutine awaiting
        // [requestId] was cancelled (queue context changed, or the
        // player was released — see
        // `QueueWindowController.releaseContext`). Only remembered
        // while the matching request is actually still in flight (see
        // [_pendingRequestIds] doc) — an id that shows up here after
        // its request already finished, or that doesn't match anything
        // this session ever saw, is simply dropped, so this never
        // grows unbounded.
        final cancelArgs = (call.arguments as Map).cast<String, dynamic>();
        final cancelledId = (cancelArgs['requestId'] as num?)?.toInt();
        if (cancelledId != null && _pendingRequestIds.contains(cancelledId)) {
          _cancelledRequestIds.add(cancelledId);
        }
        return null;

      default:
        throw MissingPluginException();
    }
  }

  /// FIX #2 — "correctly handle tracks being deleted... while a queue
  /// is active": forwards deleted ids straight to native so a track
  /// that's playing or sitting in the loaded window right now is
  /// pruned immediately, rather than only being noticed the next time
  /// native happens to re-fetch the page it was on.
  void _onTracksDeleted(List<String> identities) {
    PlayerChannel.instance.removeQueueItems(identities);
  }

  void _onTracksChanged() {
    if (_activeContextId == null) return;
    PlayerChannel.instance.refreshQueueAfterLibraryChange();
  }

  Future<void> togglePlayPause() async {
    if (state.isPlaying) {
      await PlayerChannel.instance.pause();
    } else {
      await PlayerChannel.instance.play();
    }
  }

  Future<void> seek(Duration position) => PlayerChannel.instance.seekTo(position);
  Future<void> next() => PlayerChannel.instance.skipNext();
  Future<void> previous() => PlayerChannel.instance.skipPrevious();

  @override
  void dispose() {
    _playQueueGeneration++;
    _sub.cancel();
    _deletionsSub?.cancel();
    _changesSub?.cancel();
    super.dispose();
  }
}
