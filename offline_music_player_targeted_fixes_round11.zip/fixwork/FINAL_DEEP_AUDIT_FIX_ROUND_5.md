# Final Deep Audit Fix Round

This round addressed the full issue set found in the preceding deep audits, without intentionally changing already-correct playback, paging, MediaStore identity, artwork cancellation, or lifecycle behavior except where required to close a newly found race.

## Fixed

- Removed the obsolete native `scanLibrary -> MediaStoreScanner.scanAudio()` call that referenced a non-existent method.
- Removable-volume disappearance is now treated as temporary unavailability, not deletion. Rows are retained until the volume reappears; reinsertion still triggers the bounded full-volume scan.
- Queue replacement persistence is now two-phase (`pending -> native install -> committed`) so a process death cannot pair a native queue with an unrelated persisted query.
- `playQueue()` now commits Dart queue state only after native queue installation succeeds.
- Startup no longer blocks the first usable frame on a complete MediaStore reconciliation; existing Isar data is rendered immediately and scanning continues in the background.
- MediaStore observer changed from a fixed delay to true debounce to collapse sustained provider bursts.
- Migrated from abandoned `isar` 3.1.0+1 to `isar_community` 3.3.2 and matching generator/libs. The community fork explicitly added Android 16 KB page-size support.
- Pinned Android NDK to 28.2.13676358 and disabled legacy native-library packaging, matching current Android 16 KB guidance.
- Added CI verification for 16 KB APK ZIP/ELF alignment.
- Folder index/query semantics are now case-sensitive, avoiding collisions between case-distinct directories on case-sensitive storage.
- Sidecar lyric size limiting now measures actual UTF-8 bytes.
- Embedded lyrics are normalized for BOM and capped before being returned to Dart.
- Embedded artwork has an 8 MiB input cap before bitmap decoding.
- Existing current-track metadata invalidation, queue membership checks, queue mutation serialization, and lyrics in-flight deduplication were preserved.

## Intentionally not fabricated

`track.g.dart`, `pubspec.lock`, and `gradle-wrapper.jar` are generated/resolved artifacts that require the actual Flutter/Dart/Gradle environment. The repository contains bootstrap/CI steps to generate/fetch them. No fake generated files were inserted.

## Verification limitation

The current execution environment has no Flutter SDK, Dart SDK, Gradle, or Android SDK, so a real `flutter analyze`, `flutter test`, `build_runner`, APK/AAB build, or 16 KB device run could not be executed here. Static cross-file references and archive integrity were checked after patching.

## Important dependency change

The Isar runtime/generator/libs were migrated together to `isar_community` 3.3.2. This is deliberate: the community fork's 3.2+ line documents Android 16 KB page-size support, while the original `isar` stable line remains at 3.1.0+1.
