# Final Fix Round 6 — consolidated bug fixes

## Fixed in this round

### Queue correctness
- Forward/backward queue page fetches no longer deduplicate overlapping offset pages and then advance logical indices by `newOnes.size`.
- Any overlap between a newly fetched page and the loaded window is treated as a dataset shift and triggers an identity-anchored rebase instead of corrupting logical indices.
- `QueuePageResult.startIndex` is validated before applying a page.
- `skipNext` and `skipPrevious` use the same overlap/rebase protection.

### MediaStore deletion safety
- Native deletion validation now fails closed when the candidate volume set changes during validation.
- A final volume-set check is performed after all ID queries.
- Dart deletion reconciliation aborts the pass on unstable MediaStore volume state instead of inferring mass deletion.
- Existing Isar identity/date/URI rechecks remain unchanged.

### Scan change detection
- A scan batch is now considered changed only when an existing row's persisted metadata actually differs, or a row is new.
- Existing lyrics cache is preserved only when the audio version identity fields remain stable.

### Group consistency
- Folder distinct-count now uses the same case-sensitive semantics as folder paging/count/position.
- Batched folder counts no longer lowercase folder keys and therefore cannot merge `A` and `a`.
- Folder position matching is exact, while album/artist matching remains case-insensitive.

### Android lifecycle/hardening
- `setQueueContext` validates arguments before starting the foreground service.
- Equalizer band index and level are validated against the device's actual range before persisting/applying them.
- Playback service task-removal logic uses actual `isPlaying` state.
- Playback event delivery is generation-guarded so an event queued for an old listener cannot be delivered to a newly attached listener.

### CI/release
- 16-KB ELF verification is fail-closed and uses the NDK-bundled `llvm-readelf` explicitly.
- Release tags build both APK and AAB.
- APK/AAB artifacts are uploaded/released.
- Documentation references to the old Gradle/Isar versions were updated.

## Existing fixes intentionally preserved

- Volume-aware MediaStore identity.
- Incremental scan upper-bound cursor.
- Volume reinsertion full scan.
- Bounded deletion reconciliation.
- Isar stale-delete transaction recheck.
- Queue generation guards and mutation serialization.
- Artwork consumer cancellation/reference counting.
- LRC BOM/offset handling and size limits.
- Embedded artwork input cap.
- Release-signing guard.
- 16-KB NDK/native-packaging direction.
- Existing queue persistence two-phase commit.
- Existing generated-code/Gradle bootstrap CI steps.

## Validation limitation

This environment does not contain Flutter/Dart/Android SDK, so an actual `flutter analyze`, `flutter test`, Gradle APK/AAB build, R8 run, or Android-device MediaStore/SAF/playback test could not be executed here. The source/archive was checked statically and the CI workflow was syntax-checked.
