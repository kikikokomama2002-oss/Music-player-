# Targeted bug fix: scan-row volume identity

Fixed the remaining known regression risk in `LibraryRepository`.

A MediaStore scan row is now required to contain a non-empty volume that exactly
matches the volume requested for that scan page. Missing, malformed, or
cross-volume rows fail closed instead of being silently mapped to
`external_primary`.

The scan ID is also validated as a finite, positive integer before persistence.

No previously verified queue/concurrency code was changed.
