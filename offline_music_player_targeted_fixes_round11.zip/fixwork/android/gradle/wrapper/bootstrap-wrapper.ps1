$ErrorActionPreference = "Stop"
$wrapperDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$jar = Join-Path $wrapperDir "gradle-wrapper.jar"
$url = "https://raw.githubusercontent.com/gradle/gradle/v8.13.0/gradle/wrapper/gradle-wrapper.jar"
$expected = "81a82aaea5abcc8ff68b3dfcb58b3c3c429378efd98e7433460610fecd7ae45f"
Write-Host "Fetching Gradle 8.13 wrapper JAR..."
Invoke-WebRequest -Uri $url -OutFile $jar
$actual = (Get-FileHash $jar -Algorithm SHA256).Hash.ToLowerInvariant()
if ($actual -ne $expected) {
  Remove-Item $jar -Force
  throw "Gradle wrapper JAR checksum mismatch. Expected $expected, got $actual."
}
Write-Host "Gradle wrapper JAR verified."
