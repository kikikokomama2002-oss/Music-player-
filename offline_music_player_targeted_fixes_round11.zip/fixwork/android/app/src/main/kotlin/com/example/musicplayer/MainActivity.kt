package com.example.musicplayer

import android.content.Intent
import androidx.activity.result.contract.ActivityResultContracts
import com.example.musicplayer.channels.PLAYER_CHANNEL_NAME
import com.example.musicplayer.channels.PLAYER_EVENT_CHANNEL_NAME
import com.example.musicplayer.channels.PlayerChannel
import com.example.musicplayer.channels.PlayerEventChannel
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.EventChannel
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {

    // FIX #5: SAF directory-tree picker for the sidecar-.lrc fallback
    // on Android 13+ (see SidecarLyricsResolver). Must be registered
    // before the Activity reaches STARTED, so it's a field here rather
    // than created on demand inside the MethodChannel handler.
    private val openLyricsFolder =
        registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { treeUri ->
            if (treeUri != null) {
                contentResolver.takePersistableUriPermission(
                    treeUri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            }
            pendingFolderAccessResult?.success(treeUri != null)
            pendingFolderAccessResult = null
        }

    private var pendingFolderAccessResult: MethodChannel.Result? = null
    private var playerChannel: PlayerChannel? = null

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        val playerMethodChannel = MethodChannel(
            flutterEngine.dartExecutor.binaryMessenger,
            PLAYER_CHANNEL_NAME
        )
        val channelHandler = PlayerChannel(applicationContext, playerMethodChannel) { result ->
                // Only one folder-access request can be pending at a
                // time — matches there being a single Equalizer/Lyrics
                // screen visible at once.
                if (pendingFolderAccessResult != null) {
                    result.error("SAF_REQUEST_ALREADY_PENDING", "A folder access request is already pending", null)
                } else {
                    pendingFolderAccessResult = result
                    try {
                        openLyricsFolder.launch(null)
                    } catch (e: Exception) {
                        pendingFolderAccessResult = null
                        result.error("SAF_LAUNCH_FAILED", e.message, null)
                    }
                }
            }
        playerChannel = channelHandler
        playerMethodChannel.setMethodCallHandler(channelHandler)

        EventChannel(
            flutterEngine.dartExecutor.binaryMessenger,
            PLAYER_EVENT_CHANNEL_NAME
        ).setStreamHandler(PlayerEventChannel())
    }

    override fun cleanUpFlutterEngine(flutterEngine: FlutterEngine) {
        playerChannel?.dispose()
        playerChannel = null
        pendingFolderAccessResult?.error("ENGINE_DISPOSED", "Flutter engine disposed", null)
        pendingFolderAccessResult = null
        super.cleanUpFlutterEngine(flutterEngine)
    }
}
