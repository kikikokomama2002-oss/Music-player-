package com.example.musicplayer.playback

import android.content.Intent
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService

/**
 * Foreground service exposing the shared [PlayerHolder] ExoPlayer to the
 * system as a MediaSession — this is what gives us lock-screen controls,
 * the media notification, Bluetooth/headset button support, and Android
 * Auto compatibility for free, and lets ExoPlayer's handleAudioFocus=true
 * automatically duck/pause on calls or other audio.
 *
 * Gapless playback is a property of the queue: the currently loaded
 * window of a query-backed queue is one ExoPlayer playlist (see
 * [PlayerHolder.setQueueContext] / [QueueWindowController]), so track
 * transitions reuse the same decoder pipeline instead of stopping and
 * restarting playback per song — including across a window
 * expansion/trim, which only adds/removes items, never rebuilds the
 * playlist.
 */
class PlaybackService : MediaSessionService() {

    private lateinit var mediaSession: MediaSession

    override fun onCreate() {
        super.onCreate()
        // PlayerHolder.player(context) lazily creates the ExoPlayer if it
        // doesn't exist yet, so this is safe regardless of whether a
        // MethodChannel call already created it first.
        mediaSession = MediaSession.Builder(this, PlayerHolder.player(this)).build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession {
        return mediaSession
    }

    /**
     * Only stop the service (and playback) when the task is swiped away
     * AND nothing is actively playing — otherwise keep the foreground
     * service alive so music keeps playing, matching user expectations
     * for a music app.
     */
    override fun onTaskRemoved(rootIntent: Intent?) {
        val player = PlayerHolder.peek()
        if (player == null || !player.isPlaying || player.mediaItemCount == 0) {
            stopSelf()
        }
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        mediaSession.release()
        PlayerHolder.release()
        super.onDestroy()
    }
}
