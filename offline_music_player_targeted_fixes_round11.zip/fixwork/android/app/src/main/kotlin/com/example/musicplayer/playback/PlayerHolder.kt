package com.example.musicplayer.playback

import android.content.Context
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import io.flutter.plugin.common.MethodChannel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

/**
 * Process-wide singleton holding the single ExoPlayer instance.
 *
 * Both the foreground [PlaybackService] (for lock-screen/notification/
 * Bluetooth integration) and the Flutter [PlayerChannel] / event channel
 * talk to the SAME player instance, so transport commands issued from
 * Dart and hardware button events stay in sync.
 *
 * SAFETY NOTE: [player] used to be a `lateinit var`, which crashed with
 * `lateinit property player has not been initialized` if anything (most
 * commonly the EventChannel's `onListen`, which can fire as soon as the
 * Flutter engine attaches — before any queue call has happened) touched
 * it before [init] ran. `player` is now nullable and every access goes
 * through [init]-guaranteeing accessors, so nothing can observe an
 * uninitialized player anymore, regardless of call order.
 *
 * FIX #2: playback queues are now query-backed rather than a concrete
 * `List<MediaItem>` handed over up front — see [QueueWindowController],
 * which this object delegates all queue/skip logic to.
 */
object PlayerHolder {

    @Volatile
    private var _player: ExoPlayer? = null

    // Own supervisor scope (survives individual queue-page-fetch
    // failures) for QueueWindowController's async prefetch/skip work —
    // distinct from PlayerChannel's per-call `scope.launch` since this
    // needs to keep running (e.g. a prefetch triggered by a player
    // event) independent of any single MethodChannel call's lifetime.
    private val queueScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val queueWindowController = QueueWindowController(queueScope)

    /**
     * The live ExoPlayer instance. Always safe to call — lazily
     * initializes on first access from any thread/entry point (service
     * creation, a MethodChannel call, or the EventChannel attaching)
     * instead of assuming a particular startup order.
     */
    fun player(context: Context): ExoPlayer {
        return _player ?: synchronized(this) {
            _player ?: buildPlayer(context.applicationContext).also { _player = it }
        }
    }

    /**
     * Non-initializing accessor for call sites that must not have side
     * effects (e.g. a background listener deciding whether to bother
     * emitting state). Returns null if the player hasn't been created
     * yet instead of crashing or forcing creation.
     */
    fun peek(): ExoPlayer? = _player

    private fun buildPlayer(context: Context): ExoPlayer {
        val player = ExoPlayer.Builder(context)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .build(),
                /* handleAudioFocus = */ true
            )
            .setSkipSilenceEnabled(false)
            .build()
        player.repeatMode = Player.REPEAT_MODE_OFF
        return player
    }

    /**
     * Wires [queueWindowController] to the live player + a Dart-backed
     * [QueuePageProvider]. Idempotent (re-attaching to the same player
     * is a no-op) — safe to call from every entry point that touches
     * the player, matching [player]'s own lazy-init safety story.
     */
    fun ensureQueueController(context: Context, methodChannel: MethodChannel): QueueWindowController {
        queueWindowController.attach(player(context), MethodChannelQueuePageProvider(methodChannel))
        return queueWindowController
    }

    /**
     * Establishes a new query-backed queue context — see
     * [QueueWindowController.setContext]. [items] is only the INITIAL
     * window (a small slice around [startIndex] of a possibly much
     * larger logical result set), not the complete queue; more is
     * fetched on demand via the [QueuePageProvider] passed to
     * [ensureQueueController].
     */
    fun setQueueContext(
        context: Context,
        contextId: String,
        totalCount: Int,
        startIndex: Int,
        window: List<Pair<Long, String>>,
        windowStartIndex: Int,
        startPositionMs: Long
    ) {
        player(context) // ensure created
        queueWindowController.setContext(
            contextId, totalCount, startIndex, window, windowStartIndex, startPositionMs
        )
    }

    /** See [QueueWindowController.removeItems] — FIX #2 deletion handling. */
    fun removeQueueItems(ids: Set<String>) {
        queueWindowController.removeItems(ids)
    }

    fun refreshQueueAfterLibraryChange() {
        queueWindowController.refreshAfterLibraryChange()
    }

    fun currentQueueContextId(): String? = queueWindowController.currentContextId()

    fun reattachQueueProvider(channel: MethodChannel) {
        val existing = peek() ?: return
        queueWindowController.attach(existing, MethodChannelQueuePageProvider(channel))
    }

    fun play(context: Context) {
        player(context).playWhenReady = true
    }

    fun pause(context: Context) {
        player(context).playWhenReady = false
    }

    fun seekTo(context: Context, positionMs: Long) {
        player(context).seekTo(positionMs)
    }

    /**
     * Suspend: may need to await one queue-page fetch if the logical
     * "next" track isn't in the currently loaded window yet — see
     * [QueueWindowController.skipNext].
     */
    suspend fun skipNext(context: Context): Boolean {
        player(context) // ensure created
        return queueWindowController.skipNext()
    }

    /** Suspend counterpart of [skipNext] — see [QueueWindowController.skipPrevious]. */
    suspend fun skipPrevious(context: Context): Boolean {
        player(context) // ensure created
        return queueWindowController.skipPrevious()
    }

    /** Safe even before any player exists — returns null rather than crashing. */
    fun currentTrackId(): Long? = currentTrackIdentity()?.second

    /** Returns the volume + MediaStore ID encoded in MediaItem.mediaId. */
    fun currentTrackVolume(): String? = currentTrackIdentity()?.first

    private fun currentTrackIdentity(): Pair<String, Long>? {
        val key = peek()?.currentMediaItem?.mediaId ?: return null
        val separator = key.lastIndexOf(':')
        if (separator <= 0 || separator == key.lastIndex) return null
        val volume = key.substring(0, separator)
        val id = key.substring(separator + 1).toLongOrNull() ?: return null
        return volume to id
    }

    fun release() {
        // Serialize the ENTIRE teardown with player(context)/setQueueContext.
        // Previously releaseContext() happened before taking this object's
        // monitor. Another entry point could therefore create/attach a new
        // player in that gap, only for the old release() to immediately
        // release that fresh player. Keep queue state teardown and player
        // destruction in one critical section so no new player can slip
        // between them.
        synchronized(this) {
            // Tear down the queue controller before releasing the player —
            // a fetch that outlives release() must never apply to a new
            // ExoPlayer instance.
            queueWindowController.releaseContext()
            _player?.release()
            _player = null
            // Effects are bound to the (now-dead) audio session id — never
            // let them outlive the player that created that session.
            EqualizerController.release()
        }
    }
}
