package com.example.musicplayer.scanner

import android.content.ContentUris
import android.content.Context
import android.os.Build
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Data returned by a volume-specific MediaStore audio query. */
data class TrackDto(
    val id: Long,
    val volume: String,
    val title: String?,
    val artist: String?,
    val album: String?,
    val duration: Long,
    val contentUri: String,
    val relativePath: String?,
    val displayName: String?,
    val dateModified: Long,
)

/**
 * Incremental MediaStore scanner. Every row retains the exact volume used
 * for the query and its volume-specific content URI, so MediaStore IDs are
 * never treated as globally unique.
 */
object MediaStoreScanner {

    // Keep the persisted identity stable across Android versions without
    // touching Q-only MediaStore volume APIs on legacy devices. The literal
    // is the canonical name used by the app for primary external storage.
    private const val PRIMARY_VOLUME = "external_primary"

    fun externalVolumes(context: Context): List<String> {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            return listOf(PRIMARY_VOLUME)
        }
        val volumes = MediaStore.getExternalVolumeNames(context).toList()
        check(volumes.isNotEmpty()) { "MediaStore returned no external volumes" }
        return volumes
    }

    private fun audioCollection(volume: String) =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Audio.Media.getContentUri(volume)
        } else {
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        }

    suspend fun scanAudioPage(
        context: Context,
        volume: String,
        sinceTimestampSeconds: Long = 0L,
        untilTimestampSeconds: Long = Long.MAX_VALUE,
        cursorDateModifiedSeconds: Long = Long.MAX_VALUE,
        cursorMediaStoreId: Long = Long.MAX_VALUE,
        limit: Int = 500,
    ): List<TrackDto> = withContext(Dispatchers.IO) {
        require(limit in 1..1000) { "limit must be between 1 and 1000" }

        val collection = audioCollection(volume)
        val projection = buildList {
            add(MediaStore.Audio.Media._ID)
            add(MediaStore.Audio.Media.TITLE)
            add(MediaStore.Audio.Media.ARTIST)
            add(MediaStore.Audio.Media.ALBUM)
            add(MediaStore.Audio.Media.DURATION)
            add(MediaStore.Audio.Media.DISPLAY_NAME)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                add(MediaStore.Audio.Media.RELATIVE_PATH)
            }
            add(MediaStore.Audio.Media.DATE_MODIFIED)
        }.toTypedArray()

        val selection =
            "${MediaStore.Audio.Media.IS_MUSIC}=1" +
                " AND ${MediaStore.Audio.Media.DATE_MODIFIED} > ?" +
                " AND ${MediaStore.Audio.Media.DATE_MODIFIED} <= ?" +
                " AND (" +
                "${MediaStore.Audio.Media.DATE_MODIFIED} < ?" +
                " OR (" +
                "${MediaStore.Audio.Media.DATE_MODIFIED} = ? AND " +
                "${MediaStore.Audio.Media._ID} < ?" +
                ")" +
                ")"
        val args = arrayOf(
            sinceTimestampSeconds.toString(),
            untilTimestampSeconds.toString(),
            cursorDateModifiedSeconds.toString(),
            cursorDateModifiedSeconds.toString(),
            cursorMediaStoreId.toString(),
        )

        val cursor = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val queryArgs = android.os.Bundle().apply {
                putStringArray(
                    android.content.ContentResolver.QUERY_ARG_SORT_COLUMNS,
                    arrayOf(
                        MediaStore.Audio.Media.DATE_MODIFIED,
                        MediaStore.Audio.Media._ID,
                    )
                )
                putInt(
                    android.content.ContentResolver.QUERY_ARG_SORT_DIRECTION,
                    android.content.ContentResolver.QUERY_SORT_DIRECTION_DESCENDING
                )
                putInt(android.content.ContentResolver.QUERY_ARG_LIMIT, limit)
                                putString(android.content.ContentResolver.QUERY_ARG_SQL_SELECTION, selection)
                putStringArray(android.content.ContentResolver.QUERY_ARG_SQL_SELECTION_ARGS, args)
            }
            context.contentResolver.query(collection, projection, queryArgs, null)
        } else {
            context.contentResolver.query(
                collection,
                projection,
                selection,
                args,
                "${MediaStore.Audio.Media.DATE_MODIFIED} DESC, ${MediaStore.Audio.Media._ID} DESC LIMIT $limit"
            )
        } ?: throw IllegalStateException("MediaStore query failed for volume $volume")

        cursor.use { c ->
            val idCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val albumCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
            val durationCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            val displayNameCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME)
            val relativePathCol = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                c.getColumnIndex(MediaStore.Audio.Media.RELATIVE_PATH)
            } else {
                -1
            }
            val modifiedCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_MODIFIED)

            buildList {
                while (c.moveToNext()) {
                    val id = c.getLong(idCol)
                    add(
                        TrackDto(
                            id = id,
                            volume = volume,
                            title = c.getString(titleCol),
                            artist = c.getString(artistCol),
                            album = c.getString(albumCol),
                            duration = c.getLong(durationCol),
                            contentUri = ContentUris.withAppendedId(collection, id).toString(),
                            relativePath = if (relativePathCol >= 0) c.getString(relativePathCol) else null,
                            displayName = c.getString(displayNameCol),
                            dateModified = c.getLong(modifiedCol),
                        )
                    )
                }
            }
        }
    }


    /**
     * Returns the subset of volume+ID identities that still exist. The input
     * is bounded by the caller; each volume is queried separately so an ID
     * on one volume can never validate an ID on another volume.
     */
    suspend fun findExistingMediaStoreIdentities(
        context: Context,
        candidates: List<Pair<String, Long>>,
    ): Set<String> = withContext(Dispatchers.IO) {
        if (candidates.isEmpty()) return@withContext emptySet()

        val existing = mutableSetOf<String>()
        val candidateVolumes = candidates.map { it.first }.toSet()
        val currentVolumes = externalVolumes(context).toSet()
        if (!currentVolumes.containsAll(candidateVolumes)) {
            throw IllegalStateException("MediaStore volume set changed during deletion validation")
        }
        candidates.groupBy { it.first }.forEach { (volume, volumeCandidates) ->
            // A volume that has been physically removed is absent from
            // MediaStore's current external-volume set. Treat its candidates
            // as missing instead of querying a dead collection. Queries for a
            // volume that is still present continue to fail closed on provider
            // errors so a transient MediaStore failure cannot mass-delete rows.
            if (volume !in currentVolumes) {
                throw IllegalStateException("MediaStore volume $volume disappeared during deletion validation")
            }
            val collection = audioCollection(volume)
            val ids = volumeCandidates.map { it.second }.distinct()
            if (ids.isEmpty()) return@forEach
            val placeholders = ids.joinToString(",") { "?" }
            val selection = "${MediaStore.Audio.Media._ID} IN ($placeholders)" +
                " AND ${MediaStore.Audio.Media.IS_MUSIC}=1"
            val args = ids.map(Long::toString).toTypedArray()
            val cursor = context.contentResolver.query(
                collection, arrayOf(MediaStore.Audio.Media._ID), selection, args, null
            ) ?: throw IllegalStateException("MediaStore validation query failed for volume $volume")
            cursor.use { c ->
                val idCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                while (c.moveToNext()) {
                    existing.add(identityKey(volume, c.getLong(idCol)))
                }
            }
        }
        // Final volume-set check: if a removable volume disappeared while
        // its IDs were being validated, never turn the incomplete snapshot
        // into deletions. The caller will retry on the next scan.
        val finalVolumes = externalVolumes(context).toSet()
        if (!finalVolumes.containsAll(candidateVolumes)) {
            throw IllegalStateException("MediaStore volume set changed during deletion validation")
        }
        existing
    }

    fun TrackDto.toMap(): Map<String, Any?> = mapOf(
        "id" to id,
        "volume" to volume,
        "title" to title,
        "artist" to artist,
        "album" to album,
        "duration" to duration,
        "contentUri" to contentUri,
        "relativePath" to relativePath,
        "displayName" to displayName,
        "dateModified" to dateModified,
    )

    fun identityKey(volume: String, id: Long): String = "$volume:$id"

    fun identityKeyFromContentUri(id: Long, contentUri: String): String {
        require(id > 0) { "MediaStore id must be positive" }
        val uri = android.net.Uri.parse(contentUri)
        require(uri.scheme == "content" && uri.authority == "media") {
            "MediaStore content URI is invalid"
        }
        val volume = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.getVolumeName(uri)
        } else {
            PRIMARY_VOLUME
        }
        val canonicalVolume = if (volume == "external") PRIMARY_VOLUME else volume
        require(canonicalVolume.isNotBlank()) { "MediaStore volume is invalid" }
        return "$canonicalVolume:$id"
    }
}
