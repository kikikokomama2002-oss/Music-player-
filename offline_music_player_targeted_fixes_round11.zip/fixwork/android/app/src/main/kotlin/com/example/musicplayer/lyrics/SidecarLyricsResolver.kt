package com.example.musicplayer.lyrics

import android.content.Context
import android.database.Cursor
import android.provider.DocumentsContract
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull

/**
 * FIX #5 — sidecar `.lrc` lyrics support under Scoped Storage.
 *
 * Given a track's [relativePath] (MediaStore's `RELATIVE_PATH`, e.g.
 * "Music/MyAlbum/") and [displayName] (e.g. "01 Track.mp3"), looks for
 * a sibling lyrics file in the SAME folder whose name — without
 * extension — matches the track's, case-insensitively, with a `.lrc`
 * extension (also case-insensitive). Matching requires BOTH the same
 * directory AND the same filename stem, so a same-named track in a
 * different folder is never matched.
 *
 * Two strategies, tried in order:
 *
 * 1. [viaMediaStore] — `MediaStore.Files` queried by `RELATIVE_PATH` +
 *    `DISPLAY_NAME`, via `ContentResolver`, never `raw filesystem-path column` /
 *    a raw filesystem path. This works on API 29–32, where
 *    `READ_EXTERNAL_STORAGE`/legacy access still grants MediaStore
 *    visibility into non-audio rows. On API 33+, `READ_MEDIA_AUDIO`
 *    does NOT grant visibility into non-audio MediaStore rows (a
 *    `.lrc` file is plain text, not audio) — this query simply returns
 *    no rows there, which is expected and not an error; the caller
 *    falls through to strategy 2.
 *
 * 2. [viaSaf] — Storage Access Framework fallback for API 33+ (or any
 *    case where strategy 1 found nothing): searches every directory
 *    tree the user has explicitly granted via `ACTION_OPEN_DOCUMENT_TREE`
 *    (persisted permissions — see `MainActivity.requestLyricsFolderAccess`)
 *    for a subdirectory matching [relativePath] and a child file
 *    matching the sidecar name. This is the ONLY correct way to reach
 *    an arbitrary non-audio file on API 33+ without a broad
 *    "manage all files" permission this app deliberately doesn't
 *    request. If no tree has been granted, or none contains a match,
 *    returns null — callers should surface a "grant folder access" UI
 *    action (see `LyricsScreen`) rather than silently pretending
 *    sidecar lyrics don't exist.
 */
object SidecarLyricsResolver {

    suspend fun find(
        context: Context,
        mediaStoreVolume: String?,
        relativePath: String?,
        displayName: String?
    ): String? {
        // A sidecar match is only safe when MediaStore gave us the track's
        // directory identity. Never fall back to a filename-only search when
        // RELATIVE_PATH is unavailable (notably on older Android versions).
        val safeRelativePath = relativePath?.trim()?.takeIf { it.isNotEmpty() } ?: return null
        val stem = stemOf(displayName) ?: return null
        withContext(Dispatchers.IO) {
            viaMediaStore(context, mediaStoreVolume, safeRelativePath, stem)
        }?.let { return it }
        return withContext(Dispatchers.IO) {
            withTimeoutOrNull(5_000L) {
                viaSaf(context, mediaStoreVolume, safeRelativePath, stem)
            }
        }
    }

    // -----------------------------------------------------------------
    // FIX #saf-folder-resolution (hasLyricsFolderAccess): the previous
    // check only tested whether `persistedUriPermissions` was
    // non-empty — but a listed permission can be stale (revoked from
    // Settings, the SAF provider died, the tree was deleted/moved)
    // while still appearing in that list. This actually resolves each
    // permission to a `DocumentFile` and confirms it's a real,
    // currently-readable directory before reporting access, exactly
    // like `viaSaf`'s own per-tree try/catch below.
    // -----------------------------------------------------------------
    suspend fun hasUsableFolderAccess(
        context: Context,
        mediaStoreVolume: String? = null,
        relativePath: String? = null,
        trackAware: Boolean = false,
    ): Boolean = withContext(Dispatchers.IO) {
        val trackVolume = normalizeVolume(mediaStoreVolume)
        val targetPath = relativePath?.trim('/')?.trim()?.takeIf { it.isNotEmpty() }
        if (trackAware && (trackVolume == null || targetPath == null)) return@withContext false

        context.contentResolver.persistedUriPermissions.any { permission ->
            if (!permission.isReadPermission) return@any false
            try {
                val dir = DocumentFile.fromTreeUri(context, permission.uri)
                    ?: return@any false
                if (!dir.isDirectory || !dir.canRead()) return@any false

                // With no track context this remains the original generic
                // "does any usable SAF tree exist?" check. When the caller
                // supplies a Track, however, a permission on another volume
                // (or on an unrelated folder on the same volume) must not be
                // reported as usable access for that track.
                if (trackVolume == null || targetPath == null) return@any true

                val documentId = DocumentsContract.getTreeDocumentId(permission.uri)
                val separator = documentId.indexOf(':')
                if (separator <= 0) return@any false

                val treeVolume = normalizeSafVolume(documentId.substring(0, separator))
                    ?: return@any false
                if (treeVolume != trackVolume) return@any false

                val rootPath = documentId.substring(separator + 1).trim('/')
                rootPath.isEmpty() ||
                    targetPath == rootPath ||
                    targetPath.startsWith("$rootPath/")
            } catch (e: Exception) {
                false
            }
        }
    }

    private fun stemOf(displayName: String?): String? {
        if (displayName.isNullOrBlank()) return null
        val dot = displayName.lastIndexOf('.')
        return if (dot > 0) displayName.substring(0, dot) else displayName
    }

    // -----------------------------------------------------------------
    // Strategy 1: MediaStore.Files, scoped-storage-compliant (no raw filesystem-path
    // column, no raw path) — works where the OS still grants visibility.
    // -----------------------------------------------------------------
    private fun viaMediaStore(context: Context, mediaStoreVolume: String?, relativePath: String, stem: String): String? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return null
        val volume = normalizeVolume(mediaStoreVolume) ?: return null
        val collection = MediaStore.Files.getContentUri(volume)
        val projection = arrayOf(
            MediaStore.Files.FileColumns._ID,
            MediaStore.Files.FileColumns.DISPLAY_NAME
        )

        // FIX #case-insensitive-lrc: SQLite's `=` operator is
        // locale/collation-dependent and previously only matched two
        // literal casings ("$stem.lrc" / "$stem.LRC") — a real-world
        // name like "SoNg.LrC" against a track stem of "Song" matched
        // neither. There is no portable, guaranteed-case-insensitive
        // equality operator to push into the query selection here, so
        // instead we keep the exact-directory restriction in the
        // query (still never a broader prefix scan, so a same-named
        // .lrc elsewhere on the device can't match this track) but
        // drop the DISPLAY_NAME filter from SQL entirely, then compare
        // stem + extension case-insensitively in Kotlin below, which
        // is the only way to guarantee genuinely case-insensitive
        // matching regardless of device/locale collation behavior.
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return null
        val selection = "${MediaStore.Files.FileColumns.RELATIVE_PATH}=?"
        val args = arrayOf(relativePath)

        var cursor: Cursor? = null
        return try {
            cursor = context.contentResolver.query(collection, projection, selection, args, null)
            if (cursor == null) return null
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns._ID)
            val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DISPLAY_NAME)
            var matchedId: Long? = null
            while (cursor.moveToNext()) {
                val name = cursor.getString(nameCol) ?: continue
                val ext = name.substringAfterLast('.', "")
                if (!ext.equals("lrc", ignoreCase = true)) continue
                val candidateStem = stemOf(name) ?: continue
                if (candidateStem.equals(stem, ignoreCase = true)) {
                    matchedId = cursor.getLong(idCol)
                    break
                }
            }
            val id = matchedId ?: return null
            val fileUri = Uri.withAppendedPath(collection, id.toString())
            context.contentResolver.openInputStream(fileUri)?.use { readAllText(it) }
        } catch (e: Exception) {
            // Expected on API 33+ (see class doc) or if the row simply
            // isn't visible/readable — caller falls back to SAF.
            null
        } finally {
            cursor?.close()
        }
    }

    // -----------------------------------------------------------------
    // Strategy 2: Storage Access Framework — only reaches directories
    // the user explicitly granted via requestLyricsFolderAccess().
    // -----------------------------------------------------------------
    private fun findChildByName(
        context: Context,
        treeUri: Uri,
        parentDocumentId: String,
        expectedName: String,
        wantDirectory: Boolean?
    ): DocumentFile? {
        val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(
            treeUri, parentDocumentId
        )
        val projection = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE,
        )
        context.contentResolver.query(childrenUri, projection, null, null, null)?.use { cursor ->
            val idCol = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_DOCUMENT_ID)
            val nameCol = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_DISPLAY_NAME)
            val mimeCol = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_MIME_TYPE)
            if (idCol < 0 || nameCol < 0 || mimeCol < 0) return null
            while (cursor.moveToNext()) {
                val name = cursor.getString(nameCol) ?: continue
                if (name != expectedName) continue
                val mime = cursor.getString(mimeCol) ?: continue
                val isDirectory = mime == DocumentsContract.Document.MIME_TYPE_DIR
                if (wantDirectory != null && isDirectory != wantDirectory) continue
                val childId = cursor.getString(idCol) ?: continue
                val childUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, childId)
                return DocumentFile.fromSingleUri(context, childUri)
            }
        }
        return null
    }

    private fun viaSaf(context: Context, mediaStoreVolume: String?, relativePath: String, stem: String): String? {
        val granted = context.contentResolver.persistedUriPermissions
        if (granted.isEmpty()) return null

        val targetPath = relativePath.trim('/').trim()
        if (targetPath.isEmpty()) return null

        for (permission in granted) {
            if (!permission.isReadPermission) continue

            try {
                val root = DocumentFile.fromTreeUri(context, permission.uri) ?: continue

                val documentId = DocumentsContract.getTreeDocumentId(permission.uri)
                val separator = documentId.indexOf(':')
                if (separator <= 0) continue
                val treeVolume = normalizeSafVolume(documentId.substring(0, separator)) ?: continue
                val trackVolume = normalizeVolume(mediaStoreVolume) ?: continue
                if (treeVolume != trackVolume) continue
                val rootPath = documentId.substring(separator + 1).trim('/')

                val remaining = when {
                    rootPath.isEmpty() -> targetPath.split('/').filter { it.isNotBlank() }
                    targetPath == rootPath -> emptyList()
                    targetPath.startsWith("$rootPath/") -> {
                        targetPath.substring(rootPath.length).trim('/').split('/')
                            .filter { it.isNotBlank() }
                    }
                    else -> continue
                }

                var dir = root
                var matched = true
                for (segment in remaining) {
                    val childDocumentId = DocumentsContract.getDocumentId(dir.uri)
                    val child = findChildByName(
                        context, permission.uri, childDocumentId, segment, true
                    )
                    if (child == null) {
                        matched = false
                        break
                    }
                    dir = child
                }
                if (!matched) continue

                val lyricsName = dir.let { parent ->
                    val parentId = DocumentsContract.getDocumentId(parent.uri)
                    val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(
                        permission.uri, parentId
                    )
                    var matchedUri: Uri? = null
                    context.contentResolver.query(
                        childrenUri,
                        arrayOf(
                            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                            DocumentsContract.Document.COLUMN_MIME_TYPE,
                        ),
                        null, null, null
                    )?.use { cursor ->
                        val idCol = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_DOCUMENT_ID)
                        val nameCol = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_DISPLAY_NAME)
                        val mimeCol = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_MIME_TYPE)
                        while (idCol >= 0 && nameCol >= 0 && mimeCol >= 0 && cursor.moveToNext()) {
                            val name = cursor.getString(nameCol) ?: continue
                            val mime = cursor.getString(mimeCol) ?: continue
                            if (mime == DocumentsContract.Document.MIME_TYPE_DIR) continue
                            if (stemOf(name)?.equals(stem, ignoreCase = true) == true &&
                                name.substringAfterLast('.', "").equals("lrc", ignoreCase = true)) {
                                matchedUri = DocumentsContract.buildDocumentUriUsingTree(
                                    permission.uri, cursor.getString(idCol)
                                )
                                break
                            }
                        }
                    }
                    matchedUri
                } ?: continue

                context.contentResolver.openInputStream(lyricsName)
                    ?.use { readAllText(it) }
                    ?.let { return it }
            } catch (e: Exception) {
                // Covers revoked permissions, deleted files, and dead SAF
                // providers. A failed tree never aborts the search of another
                // valid grant and never causes a cross-directory guess.
                continue
            }
        }
        return null
    }

    private const val PRIMARY_VOLUME = "external_primary"

    private fun normalizeVolume(volume: String?): String? {
        val value = volume?.trim()?.takeIf { it.isNotEmpty() } ?: return null
        return if (value.equals("external", ignoreCase = true)) PRIMARY_VOLUME else value
    }

    private fun normalizeSafVolume(volume: String): String? {
        val value = volume.trim()
        return if (value.equals("primary", ignoreCase = true) ||
            value.equals("external", ignoreCase = true)) {
            PRIMARY_VOLUME
        } else {
            value
        }
    }

    private const val MAX_LYRICS_BYTES = 1_048_576

    private fun readAllText(input: java.io.InputStream): String? {
        // Enforce the limit in actual UTF-8 bytes, not decoded UTF-16 chars.
        // A multibyte lyric file could otherwise exceed the advertised byte
        // cap substantially.
        val bytes = java.io.ByteArrayOutputStream()
        val buffer = ByteArray(8192)
        var total = 0
        while (true) {
            val read = input.read(buffer)
            if (read < 0) break
            total += read
            if (total > MAX_LYRICS_BYTES) return null
            bytes.write(buffer, 0, read)
        }
        val text = String(bytes.toByteArray(), Charsets.UTF_8)
        // FIX #5.4: a UTF-8 BOM (U+FEFF), if present, decodes as a
        // literal leading character rather than being stripped by
        // InputStreamReader — strip it here so callers (both the plain-
        // text display fallback and LrcParser, which otherwise tolerates
        // it fine since its line regex isn't start-anchored) always see
        // clean text either way.
        return text.removePrefix("\uFEFF").trim().ifEmpty { null }
    }
}
