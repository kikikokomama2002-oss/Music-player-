package com.example.musicplayer.channels

import android.content.Context
import android.database.ContentObserver
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import androidx.core.content.ContextCompat
import com.example.musicplayer.lyrics.EmbeddedLyricsReader
import com.example.musicplayer.lyrics.SidecarLyricsResolver
import com.example.musicplayer.playback.EqualizerController
import com.example.musicplayer.playback.PlaybackService
import com.example.musicplayer.playback.PlayerHolder
import com.example.musicplayer.scanner.AlbumArtLoader
import com.example.musicplayer.scanner.MediaStoreScanner
import com.example.musicplayer.scanner.MediaStoreScanner.toMap
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

const val PLAYER_CHANNEL_NAME = "com.example.musicplayer/player"

/**
 * Handles one-off commands and transport controls from Dart:
 * scanLibrary, findExistingMediaStoreIds (bounded ID batches), setQueueContext, play, pause, seekTo,
 * skipNext, skipPrevious. Delegates all playback state to the shared
 * [PlayerHolder] singleton, which is also used by the foreground
 * [PlaybackService]. Every PlayerHolder call here passes [context], so
 * the underlying ExoPlayer is created lazily and safely no matter which
 * entry point (this channel or the service) is hit first.
 *
 * @param channel FIX #2: the same channel this class handles
 *   incoming calls for, also used to make the reverse call
 *   (`requestQueuePage`) — see `PlayerHolder.ensureQueueController` /
 *   `QueuePageProvider`. Passed in rather than constructed here so
 *   there's exactly one `MethodChannel` instance for this channel name,
 *   shared in both directions.
 * @param launchLyricsFolderPicker FIX #5: launches the SAF
 *   ACTION_OPEN_DOCUMENT_TREE picker (must run from an Activity — see
 *   MainActivity) and resolves the supplied [MethodChannel.Result] with
 *   `true`/`false` once the user picks a folder or cancels.
 */
class PlayerChannel(
    private val context: Context,
    private val channel: MethodChannel,
    private val launchLyricsFolderPicker: (MethodChannel.Result) -> Unit
) : MethodChannel.MethodCallHandler {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val mediaStoreObserverHandler = Handler(Looper.getMainLooper())
    @Volatile private var disposed = false
    private val mediaStoreObserverRunnable = Runnable {
        if (!disposed) channel.invokeMethod("mediaStoreChanged", null)
    }
    private val registeredObserverUris = mutableSetOf<Uri>()

    private val mediaStoreObserver = object : ContentObserver(mediaStoreObserverHandler) {
        override fun onChange(selfChange: Boolean, uri: Uri?) {
            if (disposed) return
            // True debounce: media-provider bursts (copy/import/delete of many
            // files) collapse into one scan scheduled after the last change,
            // rather than producing a chain of back-to-back full
            // reconciliation passes.
            mediaStoreObserverHandler.removeCallbacks(mediaStoreObserverRunnable)
            mediaStoreObserverHandler.postDelayed(mediaStoreObserverRunnable, 1000)
        }
    }

    init {
        refreshMediaStoreObservers()
    }

    private fun refreshMediaStoreObservers() {
        if (disposed) return
        val desired = mutableSetOf<Uri>(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            runCatching { MediaStoreScanner.externalVolumes(context) }
                .getOrDefault(emptyList())
                .forEach { volume ->
                    desired += MediaStore.Audio.Media.getContentUri(volume)
                }
        } else {
            desired += MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        }
        val resolver = context.contentResolver
        for (uri in desired) {
            if (registeredObserverUris.add(uri)) {
                resolver.registerContentObserver(uri, true, mediaStoreObserver)
            }
        }
        // Keep stale registrations in the set. The observer is shared and
        // ContentResolver does not expose per-URI unregistering for this
        // registration; retaining the URI prevents duplicate registration
        // when a removable volume is later reinserted.
    }

    fun dispose() {
        if (disposed) return
        disposed = true
        mediaStoreObserverHandler.removeCallbacksAndMessages(null)
        context.contentResolver.unregisterContentObserver(mediaStoreObserver)
        registeredObserverUris.clear()
        scope.cancel()
    }

    private fun startService() {
        val intent = Intent(context, PlaybackService::class.java)
        ContextCompat.startForegroundService(context, intent)
    }

    private fun argumentLong(call: MethodCall, name: String, default: Long): Long {
        val raw = call.argument<Number>(name) ?: return default
        val value = raw.toLong()
        if (raw is Float && !raw.isFinite()) throw IllegalArgumentException("$name must be finite")
        if (raw is Double && !raw.isFinite()) throw IllegalArgumentException("$name must be finite")
        if (raw is Float && raw.toDouble() != value.toDouble()) throw IllegalArgumentException("$name must be an integer")
        if (raw is Double && raw != value.toDouble()) throw IllegalArgumentException("$name must be an integer")
        return value
    }

    private fun argumentInt(call: MethodCall, name: String, default: Int): Int {
        val value = argumentLong(call, name, default.toLong())
        require(value in Int.MIN_VALUE.toLong()..Int.MAX_VALUE.toLong()) {
            "$name is outside Int range"
        }
        return value.toInt()
    }

    private fun argumentNumberLong(raw: Any?, name: String): Long {
        val number = raw as? Number ?: throw IllegalArgumentException("$name must be numeric")
        val value = number.toLong()
        if (number is Float && !number.isFinite()) throw IllegalArgumentException("$name must be finite")
        if (number is Double && !number.isFinite()) throw IllegalArgumentException("$name must be finite")
        if (number is Float && number.toDouble() != value.toDouble()) throw IllegalArgumentException("$name must be an integer")
        if (number is Double && number != value.toDouble()) throw IllegalArgumentException("$name must be an integer")
        return value
    }

    override fun onMethodCall(call: MethodCall, result: MethodChannel.Result) {
        when (call.method) {
            "scanLibraryPage" -> {
                try {
                    val volume = call.argument<String>("volume")?.trim()
                    if (volume.isNullOrEmpty()) {
                        result.error("INVALID_ARGS", "volume is required", null)
                        return
                    }
                    val since = argumentLong(call, "sinceTimestampSeconds", 0L)
                    val until = argumentLong(call, "untilTimestampSeconds", Long.MAX_VALUE)
                    val cursorDate = argumentLong(call, "cursorDateModifiedSeconds", Long.MAX_VALUE)
                    val cursorId = argumentLong(call, "cursorMediaStoreId", Long.MAX_VALUE)
                    require(since >= 0) { "sinceTimestampSeconds must be non-negative" }
                    require(until >= since) { "untilTimestampSeconds must be >= sinceTimestampSeconds" }
                    require(cursorDate >= 0) { "cursorDateModifiedSeconds must be non-negative" }
                    require(cursorId >= 0) { "cursorMediaStoreId must be non-negative" }
                    val limit = argumentInt(call, "limit", 500)
                    require(limit in 1..1000) { "limit must be between 1 and 1000" }
                    scope.launch {
                        try {
                            val tracks = MediaStoreScanner.scanAudioPage(
                                context, volume, since, until, cursorDate, cursorId, limit
                            )
                            result.success(tracks.map { it.toMap() })
                        } catch (e: Exception) {
                            result.error("SCAN_PAGE_FAILED", e.message, null)
                        }
                    }
                } catch (e: Exception) {
                    result.error("INVALID_ARGS", e.message, null)
                }
            }

            "getMediaStoreVolumes" -> {
                try {
                    val volumes = MediaStoreScanner.externalVolumes(context)
                    refreshMediaStoreObservers()
                    require(volumes.isNotEmpty() && volumes.all { it.isNotBlank() }) {
                        "MediaStore returned no valid volumes"
                    }
                    result.success(volumes)
                } catch (e: Exception) {
                    result.error("VOLUME_DISCOVERY_FAILED", e.message, null)
                }
            }

            "getMediaStoreVolumeStates" -> {
                try {
                    val volumes = MediaStoreScanner.externalVolumes(context)
                    val states = volumes.map { volume ->
                        val generation = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                            MediaStore.getGeneration(context, volume)
                        } else {
                            0L
                        }
                        val version = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                            MediaStore.getVersion(context, volume) ?: ""
                        } else {
                            "legacy"
                        }
                        mapOf("volume" to volume, "generation" to generation, "version" to version)
                    }
                    result.success(states)
                } catch (e: Exception) {
                    result.error("VOLUME_STATE_FAILED", e.message, null)
                }
            }

            "findExistingMediaStoreIdentities" -> {
                @Suppress("UNCHECKED_CAST")
                val rawTracks = call.argument<List<Map<String, Any>>>("tracks")
                if (rawTracks == null) {
                    result.error("INVALID_ARGS", "tracks is required", null)
                    return
                }
                scope.launch {
                    try {
                        require(rawTracks.size <= 500) { "too many identity candidates" }
                        val candidates = rawTracks.map { item ->
                            val volume = (item["volume"] as? String)?.trim()
                                ?.takeIf { it.isNotEmpty() }
                                ?: throw IllegalArgumentException("invalid volume")
                            val id = argumentNumberLong(item["id"], "id")
                            require(id > 0) { "id must be positive" }
                            volume to id
                        }
                        require(candidates.toSet().size == candidates.size) {
                            "duplicate identity candidates"
                        }
                        val existing = MediaStoreScanner.findExistingMediaStoreIdentities(
                            context, candidates
                        )
                        result.success(existing.toList())
                    } catch (e: Exception) {
                        result.error("ID_FETCH_FAILED", e.message, null)
                    }
                }
            }

            // ---------------------------------------------------------
            // FIX #2: query-backed queue. `items`/`startIndex` used to
            // be the WHOLE queue; now `window`/`windowStartIndex` is
            // only an initial slice of a much larger logical result set
            // described by `spec` (opaque to native — see
            // PlaybackController/QueueSpec on the Dart side). See
            // PlayerHolder.setQueueContext / QueueWindowController for
            // how the rest of the queue is fetched on demand.
            // ---------------------------------------------------------
            "setQueueContext" -> {
                try {
                    val contextId = call.argument<String>("contextId")
                        ?.takeIf { it.isNotBlank() }
                        ?: throw IllegalArgumentException("contextId is required")
                    val totalCount = argumentInt(call, "totalCount", 0)
                    val startIndex = argumentInt(call, "startIndex", 0)
                    val windowStartIndex = argumentInt(call, "windowStartIndex", 0)
                    val startItemIdentity = call.argument<String>("startItemIdentity")
                        ?.takeIf { it.isNotBlank() }
                    val startPositionMs = argumentLong(call, "startPositionMs", 0L)
                    require(totalCount >= 0) { "totalCount must be non-negative" }
                    require(startIndex >= 0) { "startIndex must be non-negative" }
                    require(windowStartIndex >= 0) { "windowStartIndex must be non-negative" }
                    require(startPositionMs >= 0) { "startPositionMs must be non-negative" }
                    @Suppress("UNCHECKED_CAST")
                    val rawWindow = call.argument<List<Map<String, Any>>>("window") ?: emptyList()
                    val window = rawWindow.map { m ->
                        // Keep the id a 64-bit Long end-to-end (matches
                        // MediaStore's _ID column) — .toInt() here would
                        // silently truncate/overflow on large libraries.
                        // contentUri (not a raw filesystem path) is
                        // what gets handed to ExoPlayer.
                        Pair((m["id"] as Number).toLong(), m["contentUri"] as String)
                    }

                    if (totalCount == 0 && window.isNotEmpty()) {
                        throw IllegalArgumentException("empty queue must not contain window items")
                    }
                    if (totalCount > 0 && window.isEmpty()) {
                        throw IllegalArgumentException("non-empty queue requires an initial window")
                    }
                    require(windowStartIndex <= startIndex) {
                        "windowStartIndex must not exceed startIndex"
                    }
                    if (totalCount > 0) {
                        require(windowStartIndex.toLong() + window.size <= totalCount.toLong()) {
                            "initial window exceeds queue bounds"
                        }
                        val windowIdentities = window.map { (id, uri) ->
                            val parsed = Uri.parse(uri)
                            require(parsed.scheme == "content" && parsed.authority == "media") {
                                "initial window contains an invalid MediaStore content URI"
                            }
                            // Do not silently reinterpret an URI whose volume
                            // cannot be determined as external_primary. A
                            // malformed/foreign content URI must fail closed.
                            val uriVolume = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
                                MediaStore.getVolumeName(parsed)
                            } else {
                                MediaStoreScanner.identityKeyFromContentUri(id, uri).substringBeforeLast(':')
                            }
                            MediaStoreScanner.identityKey(uriVolume, id)
                        }
                        require(windowIdentities.size == windowIdentities.toSet().size) {
                            "initial window contains duplicate identities"
                        }
                    }
                    require(startIndex < totalCount || totalCount == 0) {
                        "startIndex is outside queue"
                    }
                    if (totalCount > 0 && startItemIdentity != null) {
                        val relative = startIndex - windowStartIndex
                        require(relative in window.indices) {
                            "start item is outside initial window"
                        }
                        val actual = window[relative]
                        val parsedActual = Uri.parse(actual.second)
                        require(parsedActual.scheme == "content" && parsedActual.authority == "media") {
                            "start item has an invalid MediaStore content URI"
                        }
                        val actualVolume = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
                            MediaStore.getVolumeName(parsedActual)
                        } else {
                            MediaStoreScanner.identityKeyFromContentUri(actual.first, actual.second).substringBeforeLast(':')
                        }
                        val actualIdentity = MediaStoreScanner.identityKey(actualVolume, actual.first)
                        require(actualIdentity == startItemIdentity) {
                            "initial window no longer contains the requested start track"
                        }
                    }
                    startService()
                    PlayerHolder.ensureQueueController(context, channel)
                    PlayerHolder.setQueueContext(
                        context, contextId, totalCount, startIndex,
                        window, windowStartIndex, startPositionMs
                    )
                    result.success(null)
                } catch (e: Exception) {
                    result.error("SET_QUEUE_FAILED", e.message, null)
                }
            }

            "removeQueueItems" -> {
                val identities = call.argument<List<String>>("identities") ?: emptyList()
                PlayerHolder.removeQueueItems(identities.toSet())
                result.success(null)
            }

            "refreshQueueAfterLibraryChange" -> {
                PlayerHolder.refreshQueueAfterLibraryChange()
                result.success(null)
            }

            "getQueueContextId" -> {
                PlayerHolder.reattachQueueProvider(channel)
                result.success(PlayerHolder.currentQueueContextId())
            }

            "play" -> {
                PlayerHolder.play(context)
                result.success(null)
            }

            "pause" -> {
                PlayerHolder.pause(context)
                result.success(null)
            }

            "seekTo" -> {
                try {
                    val positionMs = argumentLong(call, "positionMs", 0L)
                    require(positionMs >= 0) { "positionMs must be non-negative" }
                    PlayerHolder.seekTo(context, positionMs)
                    result.success(null)
                } catch (e: Exception) {
                    result.error("INVALID_ARGS", e.message, null)
                }
            }

            "skipNext" -> {
                scope.launch {
                    try {
                        PlayerHolder.skipNext(context)
                        result.success(null)
                    } catch (e: Exception) {
                        result.error("SKIP_NEXT_FAILED", e.message, null)
                    }
                }
            }

            "skipPrevious" -> {
                scope.launch {
                    try {
                        PlayerHolder.skipPrevious(context)
                        result.success(null)
                    } catch (e: Exception) {
                        result.error("SKIP_PREVIOUS_FAILED", e.message, null)
                    }
                }
            }

            // ---------------------------------------------------------
            // Lyrics (FIX #5): embedded tags first (EmbeddedLyricsReader
            // — fast, needs no extra permission, works identically on
            // every Android version), falling back to a sidecar `.lrc`
            // file in the same folder (SidecarLyricsResolver) when the
            // track has no embedded lyrics tag. See SidecarLyricsResolver
            // for why the sidecar lookup needs two strategies to work
            // reliably across API levels under Scoped Storage.
            // ---------------------------------------------------------

            "getLyrics" -> {
                val uriString = call.argument<String>("contentUri")
                if (uriString == null) {
                    result.error("INVALID_ARGS", "contentUri is required", null)
                    return
                }
                val mediaStoreVolume = call.argument<String>("mediaStoreVolume")
                val relativePath = call.argument<String>("relativePath")
                val displayName = call.argument<String>("displayName")
                scope.launch {
                    try {
                        val embedded = EmbeddedLyricsReader.read(context, uriString)
                        if (embedded != null) {
                            result.success(embedded)
                        } else {
                            val sidecar =
                                SidecarLyricsResolver.find(context, mediaStoreVolume, relativePath, displayName)
                            result.success(sidecar)
                        }
                    } catch (e: Exception) {
                        result.error("LYRICS_READ_FAILED", e.message, null)
                    }
                }
            }

            // Whether the user has granted SAF access to at least one
            // directory tree — used by the Dart lyrics screen to decide
            // whether to offer "grant folder access" for sidecar .lrc
            // files that MediaStore.Files couldn't reach (API 33+).
            "hasLyricsFolderAccess" -> {
                val trackAware = call.hasArgument("mediaStoreVolume") ||
                    call.hasArgument("relativePath")
                val mediaStoreVolume = call.argument<String>("mediaStoreVolume")
                val relativePath = call.argument<String>("relativePath")
                scope.launch {
                    result.success(
                        SidecarLyricsResolver.hasUsableFolderAccess(
                            context,
                            mediaStoreVolume,
                            relativePath,
                            trackAware,
                        )
                    )
                }
            }

            "requestLyricsFolderAccess" -> {
                launchLyricsFolderPicker(result)
            }

            // ---------------------------------------------------------
            // Album artwork: embedded art via MediaStore's own thumbnail
            // pipeline (API 29+) / MediaMetadataRetriever fallback — see
            // AlbumArtLoader, which already time-boxes and downsamples
            // both strategies. Any failure here — expected (no artwork)
            // or not (e.g. an OutOfMemoryError from a pathological
            // embedded image) — resolves to null rather than a channel
            // error: this is a best-effort row thumbnail, not something
            // a caller should have to handle as a hard failure, and
            // catching Throwable (not just Exception) means a single
            // bad file can't crash the app from this path.
            // ---------------------------------------------------------

            "getAlbumArt" -> {
                val uriString = call.argument<String>("contentUri")
                val sizePx = (call.argument<Number>("size") ?: 256).toInt().coerceIn(32, 2048)
                val version = call.argument<Number>("version")?.toLong()
                val requestId = call.argument<String>("requestId")
                if (uriString == null || requestId == null || version == null) {
                    result.error("INVALID_ARGS", "contentUri, requestId and version are required", null)
                    return
                }
                scope.launch {
                    val bytes = try {
                        AlbumArtLoader.load(context, Uri.parse(uriString), sizePx, requestId, version)
                    } catch (e: Throwable) {
                        null
                    }
                    result.success(bytes)
                }
            }

            // ---------------------------------------------------------
            // Equalizer / BassBoost, tied to the current player's
            // audioSessionId — see EqualizerController.
            //
            // FIX #6: audioSessionId may not be valid yet right after
            // setQueue() (ExoPlayer assigns it during/after prepare()),
            // so every entry point below goes through
            // EqualizerController.awaitAttached(), which waits
            // (event-driven + bounded-backoff retry) for a valid
            // session instead of reading audioSessionId exactly once
            // and giving up. This makes these calls suspend, hence the
            // scope.launch wrapper (previously synchronous).
            // ---------------------------------------------------------

            "getEqualizerState" -> {
                scope.launch {
                    try {
                        val player = PlayerHolder.player(context)
                        EqualizerController.awaitAttached(player)
                        result.success(EqualizerController.state(player.audioSessionId))
                    } catch (e: Exception) {
                        result.error("EQ_STATE_FAILED", e.message, null)
                    }
                }
            }

            "setEqualizerBand" -> {
                scope.launch {
                    try {
                        val player = PlayerHolder.player(context)
                        if (!EqualizerController.awaitAttached(player)) {
                            result.error("EQ_UNAVAILABLE", "Audio session/equalizer is unavailable", null)
                            return@launch
                        }
                        val band = (call.argument<Number>("band") ?: 0).toInt()
                        val level = (call.argument<Number>("levelMillibel") ?: 0).toInt()
                        if (!EqualizerController.setBandLevel(player.audioSessionId, band, level)) {
                            result.error("EQ_SET_BAND_FAILED", "Band level could not be applied", null)
                            return@launch
                        }
                        result.success(null)
                    } catch (e: Exception) {
                        result.error("EQ_SET_BAND_FAILED", e.message, null)
                    }
                }
            }

            "setEqualizerPreset" -> {
                scope.launch {
                    try {
                        val player = PlayerHolder.player(context)
                        if (!EqualizerController.awaitAttached(player)) {
                            result.error("EQ_UNAVAILABLE", "Audio session/equalizer is unavailable", null)
                            return@launch
                        }
                        val preset = (call.argument<Number>("preset") ?: 0).toInt()
                        if (!EqualizerController.usePreset(player.audioSessionId, preset)) {
                            result.error("EQ_SET_PRESET_FAILED", "Preset could not be applied", null)
                            return@launch
                        }
                        // Return the refreshed band levels so the UI can sync
                        // sliders to whatever the preset actually set them to.
                        result.success(EqualizerController.state(player.audioSessionId))
                    } catch (e: Exception) {
                        result.error("EQ_SET_PRESET_FAILED", e.message, null)
                    }
                }
            }

            "setBassBoost" -> {
                scope.launch {
                    try {
                        val player = PlayerHolder.player(context)
                        if (!EqualizerController.awaitAttached(player)) {
                            result.error("EQ_UNAVAILABLE", "Audio session/equalizer is unavailable", null)
                            return@launch
                        }
                        val strength = (call.argument<Number>("strengthPermille") ?: 0).toInt()
                        if (!EqualizerController.setBassBoostStrength(player.audioSessionId, strength)) {
                            result.error("EQ_BASS_FAILED", "Bass boost could not be applied", null)
                            return@launch
                        }
                        result.success(null)
                    } catch (e: Exception) {
                        result.error("EQ_BASS_FAILED", e.message, null)
                    }
                }
            }

            "setEqualizerEnabled" -> {
                scope.launch {
                    try {
                        val player = PlayerHolder.player(context)
                        if (!EqualizerController.awaitAttached(player)) {
                            result.error("EQ_UNAVAILABLE", "Audio session/equalizer is unavailable", null)
                            return@launch
                        }
                        val enabled = call.argument<Boolean>("enabled") ?: true
                        if (!EqualizerController.setEnabled(player.audioSessionId, enabled)) {
                            result.error("EQ_ENABLE_FAILED", "Equalizer could not be enabled/disabled", null)
                            return@launch
                        }
                        result.success(null)
                    } catch (e: Exception) {
                        result.error("EQ_ENABLE_FAILED", e.message, null)
                    }
                }
            }

            // Called from EqualizerScreen.dispose() so a pending bounded
            // retry (see EqualizerController.awaitAttached) doesn't keep
            // running/holding state after the user has already left the
            // screen.
            "cancelEqualizerWait" -> {
                EqualizerController.cancelWait()
                result.success(null)
            }

            // ---------------------------------------------------------
            // Album artwork cancellation (FIX #4) — see AlbumArtLoader.
            // ---------------------------------------------------------
            "cancelAlbumArt" -> {
                val uriString = call.argument<String>("contentUri")
                val sizePx = (call.argument<Number>("size") ?: 256).toInt().coerceIn(32, 2048)
                val version = call.argument<Number>("version")?.toLong()
                val requestId = call.argument<String>("requestId")
                if (uriString != null && requestId != null && version != null) {
                    AlbumArtLoader.cancel(Uri.parse(uriString), sizePx, requestId, version)
                }
                result.success(null)
            }

            else -> result.notImplemented()
        }
    }
}
