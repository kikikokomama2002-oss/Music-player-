package com.example.musicplayer.scanner

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.util.Size
import androidx.exifinterface.media.ExifInterface
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.async
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.runInterruptible
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit

/**
 * Loads embedded album artwork for a track's `content://` URI — no
 * placeholder art, no raw file paths.
 *
 * API 29+: uses `ContentResolver.loadThumbnail`, MediaStore's own
 * thumbnail pipeline. It decodes (and caches, via MediaProvider's own
 * thumbnail store) a bitmap downsampled to roughly the requested size,
 * preserving aspect ratio, without the caller ever touching the
 * full-resolution embedded image.
 *
 * API < 29 (or if `loadThumbnail` has nothing for a given row):
 * falls back to `MediaMetadataRetriever.embeddedPicture`, which reads
 * the ID3/embedded-art frame directly from the audio content URI, then
 * downscales it by hand (see [decodeSampledBitmap] — aspect ratio
 * preserving).
 *
 * The native blocking work uses the existing small retriever pool. Bitmap
 * decode/PNG encoding stays on the separate bounded decode pool.
 *
 * Shared requests are reference-counted by consumer id. A consumer can
 * release its own interest without cancelling another consumer's shared
 * operation. The underlying Deferred is cancelled only after the last
 * consumer releases it.
 */
object AlbumArtLoader {

    private const val ART_LOAD_TIMEOUT_MS = 2_500L
    private const val RETRIEVER_POOL_SIZE = 2
    private const val DECODE_POOL_SIZE = 3
    private const val MAX_EMBEDDED_ART_BYTES = 8 * 1024 * 1024

    private val decodeDispatcher =
        Executors.newFixedThreadPool(DECODE_POOL_SIZE).asCoroutineDispatcher()

    /**
     * Existing bounded native/blocking pool. It is shared by
     * MediaMetadataRetriever and ContentResolver.loadThumbnail(), because
     * both can block in provider/native code. Keeping it bounded prevents
     * pathological URIs from consuming an unbounded number of threads.
     */
    private val retrieverDispatcher =
        Executors.newFixedThreadPool(RETRIEVER_POOL_SIZE).asCoroutineDispatcher()

    private val requestScope =
        CoroutineScope(SupervisorJob() + decodeDispatcher)

    // Supervisor scope purely for fire-and-forget retriever.release()
    // calls that would otherwise block a timed-out request's response.
    private val cleanupScope = CoroutineScope(SupervisorJob() + retrieverDispatcher)
    // Bound decoded-bitmap memory independently of the request/retriever
    // pools. A 2048px RGBA bitmap is ~16 MiB before compression; keeping at
    // most two decode operations active prevents a burst of large artwork
    // requests from multiplying that allocation without bound.
    private val decodeMemorySemaphore = Semaphore(2)
    private val blockingOperationSemaphore = Semaphore(RETRIEVER_POOL_SIZE)

    private fun key(contentUri: Uri, sizePx: Int, version: Long) = "$contentUri:$sizePx:$version"

    private class SharedRequest(
        val deferred: Deferred<ByteArray?>,
        val consumers: MutableSet<String> = HashSet()
    )

    private val inFlight = ConcurrentHashMap<String, SharedRequest>()
    private val requestLock = Any()

    /** Returns compressed PNG bytes, or null if the track has no embedded artwork. */
    suspend fun load(
        context: Context,
        contentUri: Uri,
        sizePx: Int,
        consumerId: String,
        version: Long,
    ): ByteArray? {
        val safeSizePx = sizePx.coerceIn(32, 2048)
        val requestKey = key(contentUri, safeSizePx, version)
        val shared = acquire(
            requestKey = requestKey,
            consumerId = consumerId
        ) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                loadViaThumbnail(context, contentUri, safeSizePx)?.let { return@acquire it }
            }
            loadViaRetriever(context, contentUri, safeSizePx)
        }

        return try {
            shared.deferred.await()
        } finally {
            release(requestKey, consumerId, shared)
        }
    }

    /**
     * Adds one consumer to the shared request, or creates the request.
     *
     * The lock covers both lookup and consumer insertion, so subscribe and
     * release cannot race into a negative count or accidentally cancel a
     * request that has just acquired another consumer.
     */
    private fun acquire(
        requestKey: String,
        consumerId: String,
        operation: suspend () -> ByteArray?
    ): SharedRequest {
        synchronized(requestLock) {
            val existing = inFlight[requestKey]
            if (existing != null && !existing.deferred.isCompleted) {
                existing.consumers.add(consumerId)
                return existing
            }

            lateinit var created: SharedRequest
            val deferred = requestScope.async {
                operation()
            }
            created = SharedRequest(deferred)
            created.consumers.add(consumerId)
            inFlight[requestKey] = created

            deferred.invokeOnCompletion {
                synchronized(requestLock) {
                    if (inFlight[requestKey] === created) {
                        inFlight.remove(requestKey)
                    }
                    // Completion/failure ends the shared operation for every
                    // consumer. Their later finally blocks become harmless
                    // no-ops because the ids are no longer present.
                    created.consumers.clear()
                }
            }

            return created
        }
    }

    /**
     * Releases exactly one consumer's interest.
     *
     * Duplicate release/cancel calls are deliberately idempotent because the
     * consumer id is stored in a Set. The underlying operation is cancelled
     * only when the last active consumer is gone.
     */
    private fun release(
        requestKey: String,
        consumerId: String,
        shared: SharedRequest
    ) {
        var cancelUnderlying = false

        synchronized(requestLock) {
            // A completed request may already have removed its consumers and
            // in-flight entry. That is an expected late release.
            if (!shared.consumers.remove(consumerId)) return

            if (shared.consumers.isEmpty() && inFlight[requestKey] === shared) {
                inFlight.remove(requestKey)
                cancelUnderlying = true
            }
        }

        if (cancelUnderlying) {
            shared.deferred.cancel()
        }
    }

    /**
     * Releases one specific consumer's interest in an in-flight request.
     * It is safe to call this more than once.
     */
    fun cancel(contentUri: Uri, sizePx: Int, consumerId: String, version: Long) {
        val safeSizePx = sizePx.coerceIn(32, 2048)
        val requestKey = key(contentUri, safeSizePx, version)
        val shared = synchronized(requestLock) {
            inFlight[requestKey]
        } ?: return
        release(requestKey, consumerId, shared)
    }

    /**
     * ContentResolver.loadThumbnail() may perform blocking provider/native
     * work. Keep that operation on the bounded blocking/native pool, then
     * return to the decode dispatcher before converting the Bitmap to PNG.
     */
    private suspend fun loadViaThumbnail(
        context: Context,
        contentUri: Uri,
        sizePx: Int
    ): ByteArray? {
        return try {
            val bitmap = withTimeoutOrNull(ART_LOAD_TIMEOUT_MS) {
                blockingOperationSemaphore.withPermit {
                    withContext(retrieverDispatcher) {
                    runInterruptible {
                        context.contentResolver.loadThumbnail(
                            contentUri,
                            Size(sizePx, sizePx),
                            null
                        )
                    }
                    }
                }
            } ?: return null

            decodeMemorySemaphore.withPermit {
                try {
                    // loadViaThumbnail is called from requestScope/decodeDispatcher,
                    // so PNG compression remains isolated from the blocking pool.
                    if (bitmap.width.toLong() * bitmap.height.toLong() * 4L > 16L * 1024L * 1024L) {
                        return@withPermit null
                    }
                    bitmap.toPngBytes().takeIf { it.size <= 8 * 1024 * 1024 }
                } finally {
                    bitmap.recycle()
                }
            }
        } catch (e: OutOfMemoryError) {
            null
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            // No embedded/associated artwork for this row, or the provider
            // couldn't produce a thumbnail — caller falls back below.
            null
        }
    }

    private suspend fun loadViaRetriever(
        context: Context,
        contentUri: Uri,
        sizePx: Int
    ): ByteArray? {
        val retriever = MediaMetadataRetriever()
        var releasedInline = false
        return try {
            val embedded = withTimeoutOrNull(ART_LOAD_TIMEOUT_MS) {
                blockingOperationSemaphore.withPermit {
                    withContext(retrieverDispatcher) {
                    runInterruptible {
                        retriever.setDataSource(context, contentUri)
                        retriever.embeddedPicture
                    }
                    }
                }
            }
            if (embedded == null || embedded.size > MAX_EMBEDDED_ART_BYTES) {
                null
            } else {
                // The native call returned in time, so release() here is
                // safe to await inline.
                releasedInline = true
                try {
                    retriever.release()
                } catch (e: Exception) {
                    // ignore — best-effort cleanup
                }

                // This coroutine resumes on requestScope/decodeDispatcher,
                // keeping CPU-heavy bitmap work off the blocking pool.
                decodeMemorySemaphore.withPermit {
                    decodeSampledBitmap(embedded, sizePx)?.let { bitmap ->
                        try {
                            if (bitmap.width.toLong() * bitmap.height.toLong() * 4L > 16L * 1024L * 1024L) {
                                return@withPermit null
                            }
                            bitmap.toPngBytes().takeIf { it.size <= 8 * 1024 * 1024 }
                        } finally {
                            bitmap.recycle()
                        }
                    }
                }
            }
        } catch (e: OutOfMemoryError) {
            null
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            null
        } finally {
            if (!releasedInline) {
                cleanupScope.launch {
                    try {
                        retriever.release()
                    } catch (e: Throwable) {
                        // ignore — best-effort cleanup
                    }
                }
            }
        }
    }

    /**
     * Decodes [bytes] downsampled to roughly [reqSize]px via a cheap
     * bounds-only pass followed by a single inSampleSize-reduced decode.
     */
    private fun decodeSampledBitmap(bytes: ByteArray, reqSize: Int): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null

        var sampleSize = 1
        while (bounds.outWidth / (sampleSize * 2) >= reqSize &&
            bounds.outHeight / (sampleSize * 2) >= reqSize
        ) {
            sampleSize *= 2
        }

        val decodeOptions = BitmapFactory.Options().apply { inSampleSize = sampleSize }
        val sampled =
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, decodeOptions) ?: return null

        val oriented = applyExifOrientation(bytes, sampled)
        if (oriented != null && oriented !== sampled) {
            sampled.recycle()
        }
        val source = oriented ?: sampled
        if (source.width <= reqSize && source.height <= reqSize) {
            return source
        }

        val scale = reqSize.toFloat() / maxOf(source.width, source.height)
        val targetWidth = (source.width * scale).toInt().coerceAtLeast(1)
        val targetHeight = (source.height * scale).toInt().coerceAtLeast(1)
        val scaled = Bitmap.createScaledBitmap(source, targetWidth, targetHeight, true)
        if (scaled !== source) {
            source.recycle()
        }
        return scaled
    }

    /**
     * MediaMetadataRetriever returns the embedded image bytes; unlike the
     * MediaStore thumbnail pipeline, BitmapFactory does not apply JPEG EXIF
     * orientation automatically. Read only the EXIF orientation tag and
     * apply the corresponding non-destructive matrix to the already-sampled
     * bitmap. No full-resolution second decode is introduced.
     */
    private fun applyExifOrientation(bytes: ByteArray, bitmap: Bitmap): Bitmap? {
        return try {
            val exif = ExifInterface(ByteArrayInputStream(bytes))
            val orientation = exif.getAttributeInt(
                ExifInterface.TAG_ORIENTATION,
                ExifInterface.ORIENTATION_NORMAL,
            )
            if (orientation == ExifInterface.ORIENTATION_NORMAL ||
                orientation == ExifInterface.ORIENTATION_UNDEFINED
            ) {
                null
            } else {
                val matrix = Matrix()
                when (orientation) {
                    ExifInterface.ORIENTATION_FLIP_HORIZONTAL ->
                        matrix.setScale(-1f, 1f)
                    ExifInterface.ORIENTATION_ROTATE_180 ->
                        matrix.setRotate(180f)
                    ExifInterface.ORIENTATION_FLIP_VERTICAL ->
                        matrix.setScale(1f, -1f)
                    ExifInterface.ORIENTATION_TRANSPOSE -> {
                        matrix.setRotate(90f)
                        matrix.postScale(-1f, 1f)
                    }
                    ExifInterface.ORIENTATION_ROTATE_90 ->
                        matrix.setRotate(90f)
                    ExifInterface.ORIENTATION_TRANSVERSE -> {
                        matrix.setRotate(-90f)
                        matrix.postScale(-1f, 1f)
                    }
                    ExifInterface.ORIENTATION_ROTATE_270 ->
                        matrix.setRotate(-90f)
                    else -> return null
                }
                Bitmap.createBitmap(
                    bitmap,
                    0,
                    0,
                    bitmap.width,
                    bitmap.height,
                    matrix,
                    true,
                ).takeUnless { it === bitmap }
            }
        } catch (_: Exception) {
            // Some embedded images have no readable EXIF block. Their
            // decoded pixels are still valid and should pass through.
            null
        }
    }

    private fun Bitmap.toPngBytes(): ByteArray {
        val stream = ByteArrayOutputStream()
        compress(Bitmap.CompressFormat.PNG, 90, stream)
        return stream.toByteArray()
    }
}
