# Final Deep Audit & Fixes

This archive combines the findings from the supplied audit with an additional source-level pass over the patched tree.

## Fixed runtime issues

### Queue mutation correctness
- Deletion before the resident window no longer blindly reuses the old logical offset.
- Active queue deletion now rebases around a surviving queue identity using `requestQueuePageAround`.
- The current MediaStore identity is preserved when it still exists; if it was deleted, the nearest surviving loaded identity is used as the anchor.
- The native queue receives a fresh logical `startIndex` from Dart after the rebase.
- Stale page results are rejected with a monotonically increasing mutation generation.
- Forward/backward prefetches are cancelled on queue mutation and cannot apply stale results.

### Transport races
- `Next` and `Previous` intents are serialized with a dedicated coroutine mutex.
- A rapid double-tap cannot race two edge fetches and then seek against the same old queue state.
- Queue mutation generation checks are performed before and after async page resolution.

### Empty replacement queue
- A replacement context with an empty initial window now clears the previous ExoPlayer playlist instead of leaving the old queue playing under the new context.

### Query ordering / logical positions
- Track pages use deterministic ordering: `title`, then MediaStore volume, then MediaStore ID.
- Position resolution uses the same ordering for all-tracks, search, and group queues.
- This makes identity-based queue rebasing stable when duplicate titles exist.

### Lyrics
- LRC parser supports multiple timestamps on one physical line.
- Lyrics cache has a bounded TTL so sidecar `.lrc` edits cannot remain permanently stale.
- Cache writes re-read the current DB row and validate the MediaStore version before persisting the lookup result.

### SAF
- Directory path comparisons are case-sensitive.
- Filename/stem matching remains deliberately tolerant where appropriate.

### Equalizer
- Band changes catch native/effect-session failures and refresh authoritative state instead of producing unhandled async errors.
- Enabled-state changes are also guarded.

### Artwork
- Shared artwork requests remain consumer-reference-counted.
- Blocking MediaStore/provider operations are kept on a bounded dispatcher.
- Timed-out MediaMetadataRetriever instances are released asynchronously rather than leaking native resources.

### MediaStore / scanning
- Volume + MediaStore ID is used as the identity everywhere relevant.
- Incremental scan upper cursor is captured before the scan and persisted only to that bound.
- Newly inserted/reinserted volumes trigger a bounded full-volume discovery path.
- Deletion reconciliation is batched and validates identity + `dateModified` + `contentUri` before deleting an Isar row.

## Remaining environment limitation

A completely standalone build could not be executed in this sandbox because Flutter/Dart SDKs and the Gradle wrapper JAR are not installed/available locally. The source contains the existing bootstrap script for the official Gradle wrapper JAR and the CI workflow runs `build_runner` for generated Isar code.

Therefore this is a source-level correctness pass plus targeted static verification, not a claim of a successful APK build in this environment.

## Recommended CI gate

Run:

```text
flutter pub get
dart run build_runner build --delete-conflicting-outputs
flutter analyze
flutter test
flutter build apk --release
```

The queue mutation cases should also be exercised on a real Android device/emulator with:

1. delete before loaded window;
2. delete current track;
3. delete inside loaded window;
4. rapid Next at the window edge;
5. rapid Previous at the window edge;
6. rescan during playback;
7. SD-card removal/reinsertion;
8. replacing queue context while a page request is pending.
