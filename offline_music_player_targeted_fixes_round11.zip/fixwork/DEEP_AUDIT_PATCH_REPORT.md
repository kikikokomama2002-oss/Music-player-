# Deep Audit Patch Report

## Fixed

### Queue correctness
- Replaced same-offset deletion refresh with identity-anchored queue rebasing.
- Added deterministic queue ordering: title + MediaStore volume + MediaStore ID.
- Added identity-position resolution for all/search/group queue specs.
- Added native `requestQueuePageAroundIdentity` round-trip.
- Serialized async queue mutations with a coroutine `Mutex`.
- Added mutation-generation guards so stale Next/Previous/page results cannot mutate a newer queue state.
- Current-track deletion now anchors on the next surviving track, or previous track if necessary.
- Current playback position is preserved when the current track survives a rebase.

### Lyrics
- LRC parser now supports multiple timestamps on one physical line.
- Invalid second fields (>=60) are rejected.
- Positive lyrics cache is now time-bounded instead of permanent, so sidecar `.lrc` edits become visible without a manual force refresh.

### SAF
- Directory traversal matching is now case-sensitive for path segments, while `.lrc` filename/stem matching remains case-insensitive.

### Equalizer
- Native platform errors from band/enabled changes are caught and state is refreshed where possible instead of escaping as unhandled async exceptions.

### Tests
- Added focused LRC parser tests.

## Build/release note

This archive still does not contain the generated Isar `lib/data/db/track.g.dart` because it is generated from `track.dart`. Run:

`dart run build_runner build --delete-conflicting-outputs`

before compiling the Flutter app.

The Gradle wrapper bootstrap script remains the supported way to restore the wrapper JAR in environments where it is omitted from source archives.

## Verification limitation

Flutter/Dart and a Gradle executable are not installed in the audit environment, so a real `flutter analyze`, `flutter test`, or APK build could not be executed here. The patch was checked by source inspection and consistency review; it should still receive a real CI build before release.
