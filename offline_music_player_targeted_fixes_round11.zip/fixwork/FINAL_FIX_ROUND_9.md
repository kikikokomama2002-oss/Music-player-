# Final Fix Round 9 — Consolidated fixes from the last two deep audits

Applied to the Round 8 source without intentionally changing previously passing/fixed behavior.

## Fixed

1. **Rebase stale-write race**
   - Added a dedicated rebase mutex.
   - Added a separate window-generation counter.
   - Rebase results are rejected if the loaded window changed while the async query was in flight.
   - Prefetch/trim/transport window changes advance the window generation.

2. **Native initial-window validation**
   - Rejects windows extending past `totalCount`.
   - Rejects duplicate identities.
   - Keeps existing start-index/identity validation.

3. **Coalesced scan Future semantics**
   - `scanAndPersist()` now waits through the follow-up pass requested while another scan is running instead of launching it fire-and-forget after returning the original Future.

4. **Initial queue count consistency**
   - `playQueue()` re-verifies `totalCount` after resolving the initial page and retries on a count/page race.

5. **Queue page defensive validation**
   - Rejects invalid counts/offsets, out-of-bounds pages, duplicate identities, and blank content URIs before native installation.

6. **Queue page timeout**
   - Dart-backed native queue page requests have a bounded 5-second wait.
   - Cancellation remains supported.

7. **SAF lyrics timeout**
   - SAF sidecar lookup now has a bounded 5-second coroutine wait.

8. **Album-art size validation**
   - Native loader clamps requested size to 32..2048 px, matching the channel boundary.

## Deliberately preserved

- Existing MediaStore timestamp conversion.
- Volume-aware identity.
- Deletion safety and transaction re-checks.
- Existing queue ordering fixes.
- Existing queue generation/cancellation logic.
- Existing artwork request sharing/versioning.
- Existing lyrics cache behavior.
- Existing lifecycle and release behavior.
- Existing CI/release logic.

## Validation limitation

Flutter/Dart/Gradle/Android SDK executables are not installed in this audit environment, so a real `flutter analyze`, Dart test run, APK/AAB build, or device test could not be executed here.
