# Final Fix Round 7 — fixes from the last two deep-audit passes

Applied only to findings that were actionable and not already fixed.

## Fixed

1. **Legacy Android API compatibility (API 23–28)**
   - Removed runtime dependence on Q-only volume constants from legacy volume normalization.
   - Canonicalized legacy primary volume as `external_primary`.
   - Guarded `RELATIVE_PATH` cursor access behind API 29+.

2. **Queue start TOCTOU / wrong-start-track risk**
   - UI now passes the tapped track's stable `(volume, MediaStore ID)` identity.
   - PlaybackController re-resolves the identity position immediately before loading the initial window.
   - The returned page is verified to still contain that exact identity at the requested logical position.
   - A bounded retry handles a mutation between position resolution and page resolution.
   - Native validates the initial window against the same identity before installing the queue.

3. **Queue ordering mismatch**
   - Position queries now use the same case-sensitive title ordering semantics as `sortByTitle()`.

4. **Lyrics cache identity / stale-write race**
   - In-flight cache keys now include volume, MediaStore ID, modification time, content URI, duration, and display name.
   - Cache write-back validates the same identity/version fields before persisting results.
   - Positive lyrics cache is now TTL-bounded as well as negative cache, so sidecar `.lrc` edits are eventually observed without a manual refresh.

5. **Paging page-failure retry loop**
   - Failed pages enter explicit `pageErrors` state instead of being automatically re-requested by every rebuild.
   - Added explicit `retryPage()` support and UI retry controls.

6. **False-positive scan invalidation**
   - `tracksChanged` is now emitted only when `_persistScanBatch()` reports an actual row change, or when deletions occurred.

7. **AAB 16-KB verification gap**
   - Release CI now uses bundletool to materialize an APK from the release AAB and runs ZIP/ELF 16-KB alignment checks on that generated APK too.

## Intentionally unchanged

- The existing Dart-to-native scan timestamp conversion was already correct: Dart persists millisecond timestamps, the platform boundary converts them to MediaStore seconds, and native queries use seconds. No change was made there.
- Existing queue mutation serialization, deletion fail-closed logic, artwork lifecycle, equalizer validation, EventChannel generation guard, and other previously-PASS fixes were left untouched.
- `pubspec.lock` was not fabricated because Flutter/Dart tooling is unavailable in this environment; generating a lockfile without the resolver would be unsafe.

## Validation performed here

- Changed Dart/Kotlin source files passed basic structural delimiter checks.
- All `playQueue()` call sites were updated to the new stable-identity parameters.
- ZIP contents will be validated with `unzip -t` after packaging.

## Not performed here

A real `flutter analyze`, `flutter test`, Android Gradle build, APK/AAB build, or physical-device test was not available in this environment because Flutter/Dart/Android build tooling is not installed.
