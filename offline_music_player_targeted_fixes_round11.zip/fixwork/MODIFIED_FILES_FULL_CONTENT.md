# Complete modified source files

## lib/data/repositories/library_repository.dart
```dart
import 'dart:async';
import 'package:isar/isar.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../playback/player_channel.dart';
import '../db/track.dart';

const _lastScanKey = 'last_scan_timestamp_ms';

/// Safety overlap applied to the incremental scan cursor so a track
/// modified in the same second as the last scan (MediaStore's
/// DATE_MODIFIED has 1-second resolution) is never skipped.
const _scanOverlapMs = 2000;

/// Maximum number of local MediaStore IDs compared with Android in one
/// deletion-sync batch. The native query uses the same bounded batch, so
/// neither side scales in memory with the full library size.
const _deletionSyncChunkSize = 500;

/// Which grouping tab a query is for. Each case maps to a real indexed
/// column on [Track] (`album`, `artist`, `folder`), so grouping never
/// falls back to scanning/deserializing every row.
enum GroupField { album, artist, folder }

/// A group's display name and track count, resolved entirely at the DB
/// layer (distinct index scan + indexed `count()`) — never by loading
/// every [Track] in the group into memory just to read `.length`.
class GroupSummary {
  const GroupSummary(this.name, this.trackCount);
  final String name;
  final int trackCount;
}

/// Orchestrates scan -> bulk DB write -> deletion sync. The native scan
/// already runs off the platform's main thread; the Dart side keeps
/// writes batched in a single Isar transaction so refreshing a large
/// library never causes jank in the widget tree.
class LibraryRepository {
  LibraryRepository(this._isar);
  final Isar _isar;

  /// FIX #2: fires the `mediaStoreId`s of any tracks removed by
  /// [_syncDeletions] (i.e. deleted from device storage since the last
  /// scan). `PlaybackController` forwards these straight to the native
  /// queue so a track that's playing (or queued) right now gets pruned
  /// immediately instead of the native side only finding out the next
  /// time it happens to re-fetch that page.
  final _tracksDeletedController = StreamController<List<int>>.broadcast();
  Stream<List<int>> get tracksDeleted => _tracksDeletedController.stream;

  void disposeStreams() {
    _tracksDeletedController.close();
  }

  /// Scans for new/changed tracks, upserts them, and removes any track
  /// whose underlying file no longer exists in MediaStore (deleted from
  /// device storage since the last scan) so stale entries don't linger
  /// in the library.
  Future<void> scanAndPersist() async {
    final prefs = await SharedPreferences.getInstance();
    final lastScan = prefs.getInt(_lastScanKey) ?? 0;
    final scanSince =
        lastScan == 0 ? 0 : (lastScan - _scanOverlapMs).clamp(0, lastScan);

    final rawTracks =
        await PlayerChannel.instance.scanLibrary(sinceTimestamp: scanSince);

    if (rawTracks.isNotEmpty) {
      final tracks = rawTracks.map((m) => Track()
        ..mediaStoreId = m['id'] as int
        ..title = (m['title'] as String?)?.trim().isNotEmpty == true
            ? m['title'] as String
            : 'Unknown Title'
        ..artist = (m['artist'] as String?)?.trim().isNotEmpty == true
            ? m['artist'] as String
            : 'Unknown Artist'
        ..album = (m['album'] as String?)?.trim().isNotEmpty == true
            ? m['album'] as String
            : 'Unknown Album'
        ..durationMs = (m['duration'] as int?) ?? 0
        ..contentUri = (m['contentUri'] as String?) ?? ''
        ..relativePath = m['relativePath'] as String?
        ..displayName = (m['displayName'] as String?) ?? ''
        ..dateModified = (m['dateModified'] as int?) ?? 0
      ).where((t) => t.contentUri.isNotEmpty).toList();

      // Persist `folder` as a real column (see Track.computeFolder) so
      // it can be grouped/filtered via an Isar index later, instead of
      // recomputed from relativePath on every read.
      for (final t in tracks) {
        t.folder = Track.computeFolder(relativePath: t.relativePath, album: t.album);
      }

      await _isar.writeTxn(() async {
        // Upsert by mediaStoreId: replace existing rows that match, since
        // Track.mediaStoreId is a unique index this dedupes automatically
        // across rescans.
        for (final track in tracks) {
          final existing = await _isar.tracks
              .filter()
              .mediaStoreIdEqualTo(track.mediaStoreId)
              .findFirst();
          if (existing != null) track.id = existing.id;
        }
        await _isar.tracks.putAll(tracks);
      });
    }

    await _syncDeletions();

    await prefs.setInt(_lastScanKey, DateTime.now().millisecondsSinceEpoch);
  }

  /// Diffs local Track rows against MediaStore in bounded batches.
  ///
  /// The old implementation first materialized the entire MediaStore ID
  /// set and large local ID lists. This version walks Isar by primary-key
  /// ranges and asks MediaStore only about the current batch, keeping both
  /// the platform-channel payload and Dart working sets bounded.
  Future<void> _syncDeletions() async {
    // Keep the diff bounded on BOTH sides. We walk the local table by
    // primary-key ranges and ask MediaStore only about the current batch,
    // instead of first materializing every MediaStore ID into one Set.
    // This is safe for 50k–500k+ libraries and does not deserialize Track
    // objects merely to perform the membership test.
    const candidateChunkSize = _deletionSyncChunkSize;
    var lastIsarId = 0;

    while (true) {
      final isarIdsChunk = await _isar.tracks
          .where()
          .idGreaterThan(lastIsarId)
          .idProperty()
          .limit(candidateChunkSize)
          .findAll();
      if (isarIdsChunk.isEmpty) break;

      final mediaStoreIdsChunk = await _isar.tracks
          .where()
          .idGreaterThan(lastIsarId)
          .mediaStoreIdProperty()
          .limit(candidateChunkSize)
          .findAll();

      if (mediaStoreIdsChunk.length != isarIdsChunk.length) {
        // The collection changed between the two projection queries. Start
        // this small range again rather than pairing values from different
        // snapshots and risking deletion of a valid row.
        continue;
      }

      final existing = await PlayerChannel.instance.findExistingMediaStoreIds(
        mediaStoreIdsChunk,
      );

      final staleIsarIds = <int>[];
      final staleMediaStoreIds = <int>[];
      for (var i = 0; i < isarIdsChunk.length; i++) {
        final mediaStoreId = mediaStoreIdsChunk[i];
        if (!existing.contains(mediaStoreId)) {
          staleIsarIds.add(isarIdsChunk[i]);
          staleMediaStoreIds.add(mediaStoreId);
        }
      }

      if (staleIsarIds.isNotEmpty) {
        await _isar.writeTxn(() async {
          await _isar.tracks.deleteAll(staleIsarIds);
        });

        if (!_tracksDeletedController.isClosed) {
          _tracksDeletedController.add(staleMediaStoreIds);
        }
      }

      // Advance by the last ID from the snapshot we just inspected. Using
      // the primary key rather than offset pagination means deleting rows
      // from this chunk cannot shift the next chunk underneath us.
      lastIsarId = isarIdsChunk.last;
      if (isarIdsChunk.length < candidateChunkSize) break;
    }
  }

  /// Total track count via an indexed `count()` — never loads a Track
  /// object just to size a list.
  Future<int> tracksCount() => _isar.tracks.where().count();

  /// One page of the full library, sorted by title. This — not a
  /// single `.findAll()` over the whole collection — is what backs the
  /// flat "Tracks" tab now, so it only ever holds as many rows in
  /// memory as have actually been scrolled to (see
  /// `TracksPagingNotifier` in `core/providers.dart`).
  Future<List<Track>> tracksPage({required int offset, required int limit}) =>
      _isar.tracks.where().sortByTitle().offset(offset).limit(limit).findAll();

  /// One page of indexed search results — same pagination story as
  /// [tracksPage], reusing the case-insensitive indexes already defined
  /// on [Track.title]/[Track.artist]/[Track.album] instead of an
  /// in-memory `.where()` scan over a fully materialized list.
  Future<List<Track>> searchPage(
    String query, {
    required int offset,
    required int limit,
  }) {
    return _isar.tracks
        .filter()
        .titleContains(query, caseSensitive: false)
        .or()
        .artistContains(query, caseSensitive: false)
        .or()
        .albumContains(query, caseSensitive: false)
        .sortByTitle()
        .offset(offset)
        .limit(limit)
        .findAll();
  }

  /// Indexed count of the same query [searchPage] pages through — used
  /// by search-context queues (FIX #2) and the windowed search pager
  /// (FIX #1) to size `ListView.builder`/report `hasMore` without
  /// loading every match into memory just to count them.
  Future<int> searchCount(String query) {
    return _isar.tracks
        .filter()
        .titleContains(query, caseSensitive: false)
        .or()
        .artistContains(query, caseSensitive: false)
        .or()
        .albumContains(query, caseSensitive: false)
        .count();
  }

  /// Fires (with no payload) whenever any Track row changes. Paging
  /// notifiers subscribe to this to know when to reset/reload after a
  /// rescan, without Isar having to hand back the full changed dataset
  /// itself the way a `.watch()` over the whole collection would.
  Stream<void> watchTracksChanged() => _isar.tracks.watchLazy();

  /// Indexed point lookup for the currently-playing track by its
  /// unique `mediaStoreId` — an index hit, not a scan over an
  /// in-memory list built from every track in the library.
  Future<Track?> trackByMediaStoreId(int id) =>
      _isar.tracks.where().mediaStoreIdEqualTo(id).findFirst();

  /// FIX #5 — BOUNDED MEMORY FOR GROUP NAME PAGING.
  ///
  /// One page of distinct, sorted group names for [field] — the
  /// database-backed replacement for the old `distinctGroupNames()`,
  /// which returned every distinct name in the library as a single
  /// `List<String>` that callers then cached wholesale in Dart
  /// (`GroupsPagingNotifier._allNames`). That list was small relative
  /// to the full `Track` table, but it was still an unbounded-with-
  /// library-size cache: a library with a very large number of
  /// distinct albums/artists/folders grew it without limit.
  ///
  /// This instead chains `sortBy<Field>()` (index-order sort) ->
  /// `distinctBy<Field>(caseSensitive: false)` (dedupe adjacent equal
  /// keys in that sorted stream) -> `.<field>Property()` (project just
  /// the String column, not full Track rows) -> `.offset()/.limit()` —
  /// all evaluated inside Isar's query engine. Isar only walks as many
  /// sorted rows as it needs to fill this page; it does not
  /// materialize the full distinct set into Dart to satisfy one page.
  /// [GroupsPagingNotifier] (see `core/providers.dart`) calls this once
  /// per page the same way [tracksPage] is called once per page of the
  /// flat Tracks tab, and relies on `WindowedPagingNotifier`'s existing
  /// bounded-page eviction to cap how many pages of names are resident
  /// at once — exactly the same mechanism already used for [Track]
  /// pages, not a second bespoke cache.
  Future<List<String>> distinctGroupNamesPage(
    GroupField field, {
    required int offset,
    required int limit,
  }) {
    return switch (field) {
      GroupField.album => _isar.tracks
          .where()
          .sortByAlbum()
          .distinctByAlbum(caseSensitive: false)
          .albumProperty()
          .offset(offset)
          .limit(limit)
          .findAll(),
      GroupField.artist => _isar.tracks
          .where()
          .sortByArtist()
          .distinctByArtist(caseSensitive: false)
          .artistProperty()
          .offset(offset)
          .limit(limit)
          .findAll(),
      GroupField.folder => _isar.tracks
          .where()
          .sortByFolder()
          .distinctByFolder(caseSensitive: false)
          .folderProperty()
          .offset(offset)
          .limit(limit)
          .findAll(),
    };
  }

  /// Total number of distinct group names for [field] — an indexed
  /// `count()` over the same distinct query [distinctGroupNamesPage]
  /// pages through, so the Albums/Artists/Folders tabs can size
  /// `ListView.builder` (`itemCount`) without ever loading a single
  /// name into memory just to count them.
  Future<int> distinctGroupNamesCount(GroupField field) {
    return switch (field) {
      GroupField.album =>
        _isar.tracks.where().distinctByAlbum(caseSensitive: false).count(),
      GroupField.artist =>
        _isar.tracks.where().distinctByArtist(caseSensitive: false).count(),
      GroupField.folder =>
        _isar.tracks.where().distinctByFolder(caseSensitive: false).count(),
    };
  }

  /// Indexed count of tracks belonging to [name] under [field] — a
  /// single index-backed `count()` query, no rows deserialized.
  Future<int> countForGroup(GroupField field, String name) {
    return switch (field) {
      GroupField.album =>
        _isar.tracks.filter().albumEqualTo(name, caseSensitive: false).count(),
      GroupField.artist => _isar.tracks
          .filter()
          .artistEqualTo(name, caseSensitive: false)
          .count(),
      GroupField.folder => _isar.tracks
          .filter()
          .folderEqualTo(name, caseSensitive: false)
          .count(),
    };
  }

  /// FIX #3 — BATCHED GROUP COUNTS FOR A PAGE OF GROUP NAMES.
  ///
  /// Given one page of distinct group [names] (as returned by
  /// [distinctGroupNamesPage]), resolves every name's track count with
  /// exactly ONE additional Isar query — replacing the previous
  /// per-name `Future.wait(pageNames.map(countForGroup))` pattern in
  /// `GroupsPagingNotifier.fetchPage`, which issued one `count()` query
  /// per group (≈60 extra queries for a 60-name page, ~61 total).
  ///
  /// Isar 3.x has no native `GROUP BY ... COUNT(*)` for this query. This
  /// therefore uses one `.anyOf()` predicate for the whole page and walks
  /// matching rows by primary-key ranges. Only a fixed-size chunk of Track
  /// objects is materialized at a time; unlike the earlier OFFSET-based
  /// projection, the database does not repeatedly traverse an ever-growing
  /// skipped prefix for each chunk.
  ///
  /// Matches [countForGroup]'s case-insensitive equality semantics: a
  /// name's count includes every track whose [field] value matches that
  /// name case-insensitively, exactly like calling [countForGroup] once
  /// per name would. Returns 0 for a name with no matches rather than
  /// omitting it, so callers can always safely index the result by the
  /// exact name they passed in.
  Future<Map<String, int>> countsForGroups(
    GroupField field,
    List<String> names,
  ) async {
    if (names.isEmpty) return const {};

    // Isar 3.x does not expose a native GROUP BY COUNT(*) for this query.
    // Keep one batched predicate for the whole page, but walk the matching
    // rows by primary-key ranges rather than repeatedly using OFFSET. OFFSET
    // can force the database to traverse the already-skipped rows again for
    // every chunk, which becomes increasingly expensive for very large
    // groups. Only one bounded chunk of Track objects is materialized at a
    // time, so memory remains proportional to chunkSize rather than the
    // number of matching tracks.
    const chunkSize = 4096;

    final counts = <String, int>{for (final n in names) n: 0};
    final lowerToOriginal = {for (final n in names) n.toLowerCase(): n};

    Future<List<Track>> readChunk(int lastId) {
      return switch (field) {
        GroupField.album => _isar.tracks
            .where()
            .idGreaterThan(lastId)
            .filter()
            .anyOf(names, (q, name) => q.albumEqualTo(name, caseSensitive: false))
            .limit(chunkSize)
            .findAll(),
        GroupField.artist => _isar.tracks
            .where()
            .idGreaterThan(lastId)
            .filter()
            .anyOf(names, (q, name) => q.artistEqualTo(name, caseSensitive: false))
            .limit(chunkSize)
            .findAll(),
        GroupField.folder => _isar.tracks
            .where()
            .idGreaterThan(lastId)
            .filter()
            .anyOf(names, (q, name) => q.folderEqualTo(name, caseSensitive: false))
            .limit(chunkSize)
            .findAll(),
      };
    }

    var lastId = 0;
    while (true) {
      final tracks = await readChunk(lastId);
      if (tracks.isEmpty) break;

      for (final track in tracks) {
        final value = switch (field) {
          GroupField.album => track.album,
          GroupField.artist => track.artist,
          GroupField.folder => track.folder,
        };
        final original = lowerToOriginal[value.toLowerCase()];
        if (original != null) {
          counts[original] = counts[original]! + 1;
        }
      }

      lastId = tracks.last.id;
      if (tracks.length < chunkSize) break;
    }

    return counts;
  }

  /// One page of tracks belonging to [name] under [field], sorted by
  /// title. Loaded lazily — only once a group is actually expanded in
  /// the UI — and only [limit] rows at a time, so expanding many groups
  /// in a large library never holds every member track of every group
  /// in memory at once.
  Future<List<Track>> tracksForGroupPage(
    GroupField field,
    String name, {
    required int offset,
    required int limit,
  }) {
    return switch (field) {
      GroupField.album => _isar.tracks
          .filter()
          .albumEqualTo(name, caseSensitive: false)
          .sortByTitle()
          .offset(offset)
          .limit(limit)
          .findAll(),
      GroupField.artist => _isar.tracks
          .filter()
          .artistEqualTo(name, caseSensitive: false)
          .sortByTitle()
          .offset(offset)
          .limit(limit)
          .findAll(),
      GroupField.folder => _isar.tracks
          .filter()
          .folderEqualTo(name, caseSensitive: false)
          .sortByTitle()
          .offset(offset)
          .limit(limit)
          .findAll(),
    };
  }

  /// Resolves and returns lyrics text for [track], caching it on the
  /// record so re-opening the lyrics view for the same track skips the
  /// native lookup entirely.
  ///
  /// Tries [track]'s embedded tags first (ID3 USLT/COMM, a Vorbis
  /// "LYRICS"/"UNSYNCEDLYRICS" comment, or the MP4 "©lyr" atom), then
  /// falls back to a sidecar `.lrc` file in the same folder — see
  /// `PlayerChannel.getLyrics` / native `SidecarLyricsResolver` for how
  /// that fallback stays correct under Android 13+ Scoped Storage.
  ///
  /// Returns null if neither source has lyrics for this track. The
  /// returned text may itself be `.lrc`-formatted — callers should run
  /// it through `LrcParser.parse` and fall back to a plain-text display
  /// if that yields no timed lines (see `LyricsScreen`).
  ///
  /// NOTE: a `false` result is cached the same way a "no embedded tag"
  /// result always was (`lyricsChecked = true`) — including when the
  /// only thing missing was SAF folder access. If the user later grants
  /// folder access via `PlayerChannel.requestLyricsFolderAccess`,
  /// callers should force a fresh lookup (bypassing this cache) rather
  /// than trusting the stale "no lyrics" result — see `LyricsScreen`.
  Future<String?> ensureLyrics(Track track, {bool forceRefresh = false}) async {
    final cached = track.embeddedLyricsText;
    if (!forceRefresh && cached != null) return cached;
    if (!forceRefresh && track.lyricsChecked) return null;

    final text = await PlayerChannel.instance.getLyrics(
      track.contentUri,
      relativePath: track.relativePath,
      displayName: track.displayName,
    );

    await _isar.writeTxn(() async {
      track.embeddedLyricsText = text;
      track.lyricsChecked = true;
      await _isar.tracks.put(track);
    });

    return text;
  }
}
```
