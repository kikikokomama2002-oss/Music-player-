# Deep Audit Fix Round 3

Only the issues found in the immediately preceding audit were changed.
Existing MediaStore/scan/artwork/paging/playback fixes were intentionally left intact.

## Fixed
- Queue rebase now checks mutation generation after every async page lookup and before applying results.
- Queue rebase now tries the current identity and surviving nearby loaded identities when an active Search/Group query no longer contains the current track.
- If no surviving anchor is resolvable, it falls back to the previous logical window position instead of abandoning the queue.
- Library scan now emits one playback invalidation after deletion reconciliation; deletion events already cover deletion-driven queue refreshes, avoiding two rebuilds against intermediate states.
- Search/group/all queue-position comparisons now use the same case-insensitive title semantics as the indexed title queries.
- Folder group keys remain volume-qualified internally, but the UI displays only the folder path.
- Release builds now fail fast when `android/key.properties` is missing instead of silently producing a debug-signed release APK.

## Not fabricated
A real Flutter/Dart build and Android release build were not run because this offline environment has no Flutter/Dart SDK and cannot download the Gradle wrapper JAR. Therefore `track.g.dart` and `gradle-wrapper.jar` remain generated/bootstrap artifacts rather than being invented or hand-written.
