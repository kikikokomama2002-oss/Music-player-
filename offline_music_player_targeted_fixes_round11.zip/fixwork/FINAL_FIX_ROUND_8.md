# Consolidated Fix Round 8

Applied the actionable findings from the two immediately preceding deep-audit passes, while leaving previously-PASS fixes unchanged.

## Fixed

1. **Unified queue ordering semantics**
   - `tracksPage`, search/group pages, and all corresponding position calculations now use the same case-insensitive title ordering semantics from the indexed `Track.title` order, followed by `(mediaStoreVolume, mediaStoreId)` as deterministic tie-breakers.

2. **Queue rebase TOCTOU hardening**
   - Native `requestQueuePageAroundIdentity` handling now re-resolves position/count/page and verifies the exact requested identity at the expected logical slot, with bounded retries.
   - Native queue rebase commits now re-check generation/context/player identity immediately before installing the result.

3. **Normal queue-page TOCTOU hardening**
   - Native-to-Dart queue page requests now verify the ordered identity span across consecutive reads before returning a page, preventing an in-flight library mutation from silently shifting an offset without overlapping the resident window.

4. **`skipPrevious` failure semantics**
   - A failed previous-page request is no longer interpreted as a command to restart the current track. It now surfaces as a transport error; restart behavior remains only for the intentional normal "no previous" case.

5. **`skipNext` failure semantics**
   - A failed/invalid next-page request is no longer silently treated as end-of-queue. End-of-queue remains a normal false result; provider/page failures now surface as transport errors.

6. **Queue mutation lock scope**
   - Slow provider/Isar rebase work no longer runs while the short-lived mutation mutex is held.
   - The mutex is now used only for the final state/ExoPlayer commit, with generation/context/player checks preventing stale results from being installed.
   - Forward/backward overlap detection and explicit transport rebase paths follow the same rule.

7. **Rebase fallback selection**
   - When the current identity and nearby anchors have disappeared from the active query, the fallback window now chooses the item closest to the old logical position rather than implicitly jumping to index 0.

8. **Artwork version identity**
   - Native album-art in-flight deduplication/cancellation keys now include the Dart `version` (MediaStore modification version), matching Riverpod's versioned cache key and preventing an old request from being shared with a newer artwork generation for the same URI/size.

9. **Lyrics cache documentation**
   - Track schema documentation now reflects the actual bounded positive-cache TTL instead of describing positive cache entries as valid until audio modification only.

## Intentionally unchanged

- Existing MediaStore timestamp conversion, deletion fail-closed logic, queue generation invalidation, volume-aware identity, artwork consumer reference counting, equalizer validation, EventChannel generation guard, scan coalescing, and other previously-PASS fixes were not rewritten.
- `pubspec.lock` was not fabricated because Dart/Flutter tooling is unavailable in this environment; a resolver-generated lockfile is required for correctness.
- `gradle-wrapper.jar` was not fabricated or replaced with an unverified binary; the existing checksum-verified bootstrap mechanism remains in place.
- Real Flutter analyze/test, Android Gradle build, APK/AAB build, and physical-device stress testing remain unavailable in this sandbox.

## Validation performed

- Checked all changed cross-file call signatures for album-art version propagation.
- Checked queue ordering queries and position queries for consistent title case semantics.
- Checked queue mutation paths to ensure rebase calls are no longer nested inside the mutation mutex during provider/Isar awaits.
- Archive integrity is verified with `unzip -t` after packaging.
