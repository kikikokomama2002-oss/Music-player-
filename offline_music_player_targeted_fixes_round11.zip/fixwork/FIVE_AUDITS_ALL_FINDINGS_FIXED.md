# Five-Audit Fix Round

This round fixes the unresolved findings accumulated across the five audits.
Previously-PASS areas were not re-audited or rewritten except where a known finding explicitly required a boundary change.

## Fixed

### Queue concurrency / transport
- Forward prefetch now captures and validates `windowGeneration`.
- Backward prefetch now validates both mutation and window generations.
- `skipNext()` now validates the captured window generation before installing/using a page.
- Native initial queue context rejects malformed bounds, empty-queue nonzero indices, duplicate identities, and non-content URIs.
- Queue-page parsing is strict: malformed items are rejected rather than silently dropped.
- Queue-page parsing validates total/start bounds, requested page size, positive MediaStore IDs, content URI scheme, identity uniqueness, and declared volume vs URI volume.
- Rebase fallback stays near the previous logical position instead of jumping directly to index 0 when the query shrinks.

### Scanner / MediaStore lifecycle
- New tracks now mark the library as changed and emit the normal coalesced invalidation.
- MediaStore deletion-reconciliation failures now propagate instead of being treated as success.
- Scan cursor/known-volume persistence occurs only after successful deletion reconciliation and a stable volume-set check.
- A changing volume set aborts the scan so the next pass retries from the previous cursor.
- Scanner cursor progress is checked to prevent an OEM/provider returning the same full-page boundary forever.
- A second volume-set check is performed immediately before stale-row deletion.

### Paging / query correctness
- Paging rejects negative page indices and oversized page results.
- Group page loading retries when names/counts are unstable during active library mutation.
- Non-ASCII album/artist group counts use Isar's own case-insensitive comparator rather than Dart lower-casing.
- Search position and group position no longer use Dart lower-casing as a precondition for DB membership.

### Queue persistence
- Restored queue descriptors are checked against the current Isar dataset before activation.
- Persisted queue descriptors now expire after 24 hours.

### Artwork / effects / platform boundaries
- Album-art version is now required by the Dart/native API instead of silently defaulting to `0`.
- Artwork decoded-memory concurrency is bounded and oversized decoded/PNG outputs are rejected.
- Equalizer preset indices are validated.
- BassBoost setters verify device support and catch provider exceptions.
- Player event identity is derived from the same ExoPlayer snapshot instead of separate PlayerHolder reads.

### Database identity / release hardening
- Isar is opened/reused under an explicit database name rather than grabbing an arbitrary existing instance.
- Release keystore properties are validated early, including required values and actual keystore-file existence.

## Not changed

Previously-PASS functionality was intentionally left untouched unless one of the unresolved findings above required a direct boundary modification.

## Verification limitations

The current environment does not contain the project's Flutter SDK/Android SDK/Gradle dependency cache, so a full `flutter analyze`, Dart test suite, APK/AAB build, and device/OEM runtime test could not be executed here. Kotlin source parsing was checked with the available standalone compiler; dependency-resolution errors are expected because Android/Flutter libraries are not installed in this environment.
