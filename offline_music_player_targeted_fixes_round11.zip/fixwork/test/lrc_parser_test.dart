import 'package:flutter_test/flutter_test.dart';
import 'package:offline_music_player/features/lyrics/lrc_parser.dart';

void main() {
  test('parses multiple timestamps on one LRC line', () {
    final lines = LrcParser.parse('[00:12.34][00:25.10]Same lyric\n[01:02.5]Next');
    expect(lines.length, 3);
    expect(lines[0].timestamp, const Duration(seconds: 12, milliseconds: 340));
    expect(lines[1].timestamp, const Duration(seconds: 25, milliseconds: 100));
    expect(lines[2].timestamp, const Duration(minutes: 1, seconds: 2, milliseconds: 500));
    expect(lines[0].text, 'Same lyric');
    expect(lines[1].text, 'Same lyric');
  });

  test('ignores malformed timestamps and metadata', () {
    final lines = LrcParser.parse('[ar:Artist]\n[00:99.00]bad\n[00:01.00]ok');
    expect(lines.length, 1);
    expect(lines.single.text, 'ok');
  });
  test('applies LRC offset metadata and strips a UTF-8 BOM', () {
    final lines = LrcParser.parse('\uFEFF[offset:+150]\n[00:01.00]Hello');
    expect(lines.single.timestamp, const Duration(milliseconds: 1150));
  });

  test('negative LRC offsets never produce negative playback timestamps', () {
    final lines = LrcParser.parse('[offset:-2000]\n[00:01.00]Hello');
    expect(lines.single.timestamp, Duration.zero);
  });
}
